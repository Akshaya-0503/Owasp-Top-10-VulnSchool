package com.cyberdojo.service;

import com.cyberdojo.model.User;
import com.cyberdojo.model.UserProgress;
import com.cyberdojo.repository.UserProgressRepository;

//import tools.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class ProgressService {

    @Autowired
    private UserProgressRepository progressRepository;

    private ObjectMapper objectMapper = new ObjectMapper();

    // Get all progress for a user
    public Map<String, Object> getUserProgress(User user) {
        List<UserProgress> progressList = progressRepository.findByUser(user);
        Map<String, Object> progress = new HashMap<>();

        for (UserProgress p : progressList) {
            Map<String, Object> moduleProgress = new HashMap<>();
            moduleProgress.put("status", p.getStatus());
            moduleProgress.put("startedAt", p.getStartedAt());
            moduleProgress.put("completedAt", p.getCompletedAt());
            moduleProgress.put("lastAccessed", p.getLastAccessed());

            // Parse completed labs from JSON
            if (p.getCompletedLabs() != null && !p.getCompletedLabs().isEmpty()) {
                try {
                    List<String> labs = objectMapper.readValue(p.getCompletedLabs(), List.class);
                    moduleProgress.put("completedLabs", labs);
                } catch (Exception e) {
                    moduleProgress.put("completedLabs", new ArrayList<>());
                }
            } else {
                moduleProgress.put("completedLabs", new ArrayList<>());
            }

            progress.put(p.getModuleId(), moduleProgress);
        }

        return progress;
    }

    // Update progress for a module
    public UserProgress updateProgress(User user, String moduleId, String status, List<String> completedLabs) {
        Optional<UserProgress> existing = progressRepository.findByUserAndModuleId(user, moduleId);
        UserProgress progress;

        if (existing.isPresent()) {
            progress = existing.get();
        } else {
            progress = new UserProgress();
            progress.setUser(user);
            progress.setModuleId(moduleId);
            progress.setStartedAt(LocalDateTime.now());
        }

        progress.setStatus(status);
        progress.setLastAccessed(LocalDateTime.now());

        // Save completed labs as JSON
        try {
            String labsJson = objectMapper
                    .writeValueAsString(completedLabs != null ? completedLabs : new ArrayList<>());
            progress.setCompletedLabs(labsJson);
        } catch (Exception e) {
            progress.setCompletedLabs("[]");
        }

        if ("COMPLETED".equals(status) && progress.getCompletedAt() == null) {
            progress.setCompletedAt(LocalDateTime.now());
        }

        return progressRepository.save(progress);
    }

    // Get progress for a specific module
    public Optional<UserProgress> getModuleProgress(User user, String moduleId) {
        return progressRepository.findByUserAndModuleId(user, moduleId);
    }
}