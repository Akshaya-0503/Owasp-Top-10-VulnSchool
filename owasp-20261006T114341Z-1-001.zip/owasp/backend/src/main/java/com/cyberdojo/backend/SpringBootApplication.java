package com.cyberdojo.backend;

public @interface SpringBootApplication {

}
