const API_BASE_URL = 'http://localhost:8080/api';

export const getModule = async (moduleId) => {
    const response = await fetch(`${API_BASE_URL}/content/modules/${moduleId}`);
    return response.json();
};

export const getLabsForModule = async (moduleId) => {
    const response = await fetch(`${API_BASE_URL}/content/modules/${moduleId}/labs`);
    return response.json();
};