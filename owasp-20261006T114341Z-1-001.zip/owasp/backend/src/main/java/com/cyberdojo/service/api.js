const API_BASE_URL = 'http://localhost:8080/api';

export const login = async (email, password) => {
    try {
        console.log('Attempting login to:', `${API_BASE_URL}/auth/login`);
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });
        const data = await response.json();
        console.log('Login response:', data);

        if (data.success && data.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
        }
        return data;
    } catch (error) {
        console.error('Login error:', error);
        return { success: false, message: 'Network error - Is backend running on port 8080?' };
    }
};