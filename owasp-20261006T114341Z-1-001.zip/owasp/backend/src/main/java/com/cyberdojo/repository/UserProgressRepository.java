package com.cyberdojo.repository;

import com.cyberdojo.model.User;
import com.cyberdojo.model.UserProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserProgressRepository extends JpaRepository<UserProgress, Long> {
    List<UserProgress> findByUser(User user);

    Optional<UserProgress> findByUserAndModuleId(User user, String moduleId);

    void deleteByUser(User user);
}