package com.cyberdojo.dto;

public class LoginResponse {
    
}
