package com.cyberdojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyberdojoApplication {
    public static void main(String[] args) {
        SpringApplication.run(CyberdojoApplication.class, args);
        System.out.println("=========================================");
        System.out.println("🚀 CyberDojo Backend Started Successfully!");
        System.out.println("📝 API available at: http://localhost:8080");
        System.out.println("=========================================");
    }
}