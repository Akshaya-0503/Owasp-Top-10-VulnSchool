package com.cyberdojo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "modules")
public class Module {

    @Id
    private String id;

    private String title;
    private String difficulty;
    private String cvss;
    private String description;

    @Column(columnDefinition = "TEXT")
    private String theory;

    @Column(columnDefinition = "TEXT")
    private String vulnerableCode;

    @Column(columnDefinition = "TEXT")
    private String secureCode;

    // Default constructor
    public Module() {
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public String getCvss() {
        return cvss;
    }

    public String getDescription() {
        return description;
    }

    public String getTheory() {
        return theory;
    }

    public String getVulnerableCode() {
        return vulnerableCode;
    }

    public String getSecureCode() {
        return secureCode;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public void setCvss(String cvss) {
        this.cvss = cvss;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTheory(String theory) {
        this.theory = theory;
    }

    public void setVulnerableCode(String vulnerableCode) {
        this.vulnerableCode = vulnerableCode;
    }

    public void setSecureCode(String secureCode) {
        this.secureCode = secureCode;
    }
}