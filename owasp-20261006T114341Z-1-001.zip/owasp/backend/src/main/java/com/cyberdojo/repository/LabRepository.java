package com.cyberdojo.repository;

import com.cyberdojo.model.Lab;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LabRepository extends JpaRepository<Lab, String> {
    List<Lab> findByModuleId(String moduleId);

    List<Lab> findByModuleIdOrderByIdAsc(String moduleId);
}