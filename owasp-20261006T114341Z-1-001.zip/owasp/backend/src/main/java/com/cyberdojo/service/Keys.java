package com.cyberdojo.service;

import java.security.Key;

public class Keys {

    public static Key hmacShaKeyFor(byte[] keyBytes) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'hmacShaKeyFor'");
    }

}
