package com.cyberdojo.dto;

public class UserDto {
    
}
