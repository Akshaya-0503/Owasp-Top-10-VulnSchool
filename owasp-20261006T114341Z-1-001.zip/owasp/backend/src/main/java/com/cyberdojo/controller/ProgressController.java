package com.cyberdojo.controller;

import com.cyberdojo.model.User;
import com.cyberdojo.repository.UserRepository;
import com.cyberdojo.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/progress")
@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174" })
public class ProgressController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtService;

    // In-memory storage for demo (replace with database later)
    private static final Map<String, Map<String, Object>> userProgress = new ConcurrentHashMap<>();

    // Get user progress
    @GetMapping("/my-progress")
    public ResponseEntity<Map<String, Object>> getMyProgress(@RequestHeader("Authorization") String authHeader) {
        Map<String, Object> response = new HashMap<>();

        try {
            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "User not found");
                return ResponseEntity.badRequest().body(response);
            }

            User user = userOpt.get();
            String userKey = "user_" + user.getId();

            // Get progress for this user
            Map<String, Object> progress = userProgress.getOrDefault(userKey, new HashMap<>());

            response.put("success", true);
            response.put("progress", progress);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to get progress: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Update user progress
    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updateProgress(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody Map<String, Object> request) {

        Map<String, Object> response = new HashMap<>();

        try {
            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "User not found");
                return ResponseEntity.badRequest().body(response);
            }

            User user = userOpt.get();
            String userKey = "user_" + user.getId();
            String moduleId = (String) request.get("moduleId");
            String status = (String) request.get("status");
            List<String> completedLabs = (List<String>) request.getOrDefault("completedLabs", new ArrayList<>());

            // Get existing progress or create new
            Map<String, Object> userProg = userProgress.getOrDefault(userKey, new HashMap<>());

            // Update module progress
            Map<String, Object> moduleProgress = new HashMap<>();
            moduleProgress.put("status", status);
            moduleProgress.put("completedLabs", completedLabs);
            moduleProgress.put("lastUpdated", new Date().toString());

            userProg.put(moduleId, moduleProgress);
            userProgress.put(userKey, userProg);

            response.put("success", true);
            response.put("message", "Progress updated successfully");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to update progress: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }
}