package com.cyberdojo.service;

import java.util.List;

public class ObjectMapper {

    public List<String> readValue(String completedLabs, Class<List> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'readValue'");
    }

    public String writeValueAsString(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'writeValueAsString'");
    }

}
