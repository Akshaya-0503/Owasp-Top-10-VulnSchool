package com.cyberdojo.controller;

import com.cyberdojo.model.User;
import com.cyberdojo.model.PasswordResetToken;
import com.cyberdojo.repository.UserRepository;
import com.cyberdojo.repository.PasswordResetTokenRepository;
import com.cyberdojo.service.JwtService;
import com.cyberdojo.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:3000" }, allowCredentials = "true")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordResetTokenRepository tokenRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EmailService emailService; // ADD THIS LINE

    // Register new user
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();

        try {
            if (userRepository.existsByEmail(user.getEmail())) {
                response.put("success", false);
                response.put("message", "Email already registered!");
                return ResponseEntity.badRequest().body(response);
            }

            if (user.getPassword().length() < 6) {
                response.put("success", false);
                response.put("message", "Password must be at least 6 characters!");
                return ResponseEntity.badRequest().body(response);
            }

            user.setPassword(passwordEncoder.encode(user.getPassword()));
            user.setCreatedAt(LocalDateTime.now());
            user.setActive(true);
            user.setRole("USER");

            User savedUser = userRepository.save(user);

            // Send welcome email
            try {
                emailService.sendWelcomeEmail(user.getEmail(), user.getName());
            } catch (Exception e) {
                System.out.println("Welcome email not sent: " + e.getMessage());
            }

            response.put("success", true);
            response.put("message", "Registration successful!");
            response.put("user", Map.of(
                    "id", savedUser.getId(),
                    "name", savedUser.getName(),
                    "email", savedUser.getEmail()));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Registration failed: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Login user
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> loginRequest) {
        Map<String, Object> response = new HashMap<>();

        try {
            String email = loginRequest.get("email");
            String password = loginRequest.get("password");

            Optional<User> userOpt = userRepository.findByEmail(email);

            if (userOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "Invalid email or password!");
                return ResponseEntity.badRequest().body(response);
            }

            User user = userOpt.get();

            if (!passwordEncoder.matches(password, user.getPassword())) {
                response.put("success", false);
                response.put("message", "Invalid email or password!");
                return ResponseEntity.badRequest().body(response);
            }

            if (!user.isActive()) {
                response.put("success", false);
                response.put("message", "Account is disabled!");
                return ResponseEntity.badRequest().body(response);
            }

            String token = jwtService.generateToken(user.getEmail());

            response.put("success", true);
            response.put("message", "Login successful!");
            response.put("token", token);
            response.put("user", Map.of(
                    "id", user.getId(),
                    "name", user.getName(),
                    "email", user.getEmail()));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Login failed: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Get current user
    @GetMapping("/me")
    public ResponseEntity<Map<String, Object>> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        Map<String, Object> response = new HashMap<>();

        try {
            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            Optional<User> userOpt = userRepository.findByEmail(email);

            if (userOpt.isEmpty()) {
                response.put("success", false);
                response.put("message", "User not found!");
                return ResponseEntity.notFound().build();
            }

            User user = userOpt.get();

            response.put("success", true);
            response.put("user", Map.of(
                    "id", user.getId(),
                    "name", user.getName(),
                    "email", user.getEmail()));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to get user info!");
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Forgot password - SENDS REAL EMAIL
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestBody Map<String, String> request) {
        Map<String, String> response = new HashMap<>();
        String email = request.get("email");

        try {
            Optional<User> userOpt = userRepository.findByEmail(email);

            if (userOpt.isEmpty()) {
                // For security, don't reveal if email exists
                response.put("message", "If your email is registered, you will receive a reset link.");
                return ResponseEntity.ok(response);
            }

            User user = userOpt.get();

            // Delete existing tokens
            tokenRepository.deleteByUserEmail(email);

            // Generate new token
            String token = UUID.randomUUID().toString();

            PasswordResetToken resetToken = new PasswordResetToken();
            resetToken.setToken(token);
            resetToken.setUser(user);
            resetToken.setExpiryDate(LocalDateTime.now().plusHours(1));
            resetToken.setUsed(false);

            tokenRepository.save(resetToken);

            // SEND REAL EMAIL
            emailService.sendPasswordResetEmail(email, token);

            response.put("message", "Password reset instructions have been sent to your email.");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("message", "Failed to process request: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Reset password
    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@RequestBody Map<String, String> request) {
        Map<String, String> response = new HashMap<>();
        String token = request.get("token");
        String newPassword = request.get("newPassword");

        try {
            Optional<PasswordResetToken> tokenOpt = tokenRepository.findByToken(token);

            if (tokenOpt.isEmpty()) {
                response.put("success", "false");
                response.put("message", "Invalid or expired reset token!");
                return ResponseEntity.badRequest().body(response);
            }

            PasswordResetToken resetToken = tokenOpt.get();

            if (resetToken.isUsed()) {
                response.put("success", "false");
                response.put("message", "Reset token has already been used!");
                return ResponseEntity.badRequest().body(response);
            }

            if (resetToken.getExpiryDate().isBefore(LocalDateTime.now())) {
                response.put("success", "false");
                response.put("message", "Reset token has expired!");
                return ResponseEntity.badRequest().body(response);
            }

            if (newPassword.length() < 6) {
                response.put("success", "false");
                response.put("message", "Password must be at least 6 characters!");
                return ResponseEntity.badRequest().body(response);
            }

            User user = resetToken.getUser();
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);

            resetToken.setUsed(true);
            tokenRepository.save(resetToken);

            response.put("success", "true");
            response.put("message", "Password reset successfully!");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", "false");
            response.put("message", "Password reset failed!");
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // Change password
    @PostMapping("/change-password")
    public ResponseEntity<Map<String, String>> changePassword(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody Map<String, String> request) {

        Map<String, String> response = new HashMap<>();

        try {
            String token = authHeader.substring(7);
            String email = jwtService.extractEmail(token);

            Optional<User> userOpt = userRepository.findByEmail(email);

            if (userOpt.isEmpty()) {
                response.put("success", "false");
                response.put("message", "User not found!");
                return ResponseEntity.badRequest().body(response);
            }

            User user = userOpt.get();
            String currentPassword = request.get("currentPassword");
            String newPassword = request.get("newPassword");

            if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
                response.put("success", "false");
                response.put("message", "Current password is incorrect!");
                return ResponseEntity.badRequest().body(response);
            }

            if (newPassword.length() < 6) {
                response.put("success", "false");
                response.put("message", "New password must be at least 6 characters!");
                return ResponseEntity.badRequest().body(response);
            }

            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);

            response.put("success", "true");
            response.put("message", "Password changed successfully!");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", "false");
            response.put("message", "Failed to change password!");
            return ResponseEntity.internalServerError().body(response);
        }
    }
}