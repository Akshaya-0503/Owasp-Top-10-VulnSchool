package com.cyberdojo.backend;

public class SpringApplication {

    public static void run(Class<BackendApplication> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
