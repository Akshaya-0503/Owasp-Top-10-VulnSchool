package com.cyberdojo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "labs")
public class Lab {

    @Id
    private String id;

    private String moduleId;
    private String title;
    private String type;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String task;
    private String endpoint;
    private String examplePayload;
    private String hint;
    private String impact;

    @Column(columnDefinition = "TEXT")
    private String vulnerableCode;

    @Column(columnDefinition = "TEXT")
    private String secureCode;

    // Default constructor
    public Lab() {
    }

    // Parameterized constructor
    public Lab(String id, String moduleId, String title, String type,
            String description, String task, String endpoint,
            String examplePayload, String hint, String impact,
            String vulnerableCode, String secureCode) {
        this.id = id;
        this.moduleId = moduleId;
        this.title = title;
        this.type = type;
        this.description = description;
        this.task = task;
        this.endpoint = endpoint;
        this.examplePayload = examplePayload;
        this.hint = hint;
        this.impact = impact;
        this.vulnerableCode = vulnerableCode;
        this.secureCode = secureCode;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getModuleId() {
        return moduleId;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public String getTask() {
        return task;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public String getExamplePayload() {
        return examplePayload;
    }

    public String getHint() {
        return hint;
    }

    public String getImpact() {
        return impact;
    }

    public String getVulnerableCode() {
        return vulnerableCode;
    }

    public String getSecureCode() {
        return secureCode;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public void setExamplePayload(String examplePayload) {
        this.examplePayload = examplePayload;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public void setVulnerableCode(String vulnerableCode) {
        this.vulnerableCode = vulnerableCode;
    }

    public void setSecureCode(String secureCode) {
        this.secureCode = secureCode;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "Lab{" +
                "id='" + id + '\'' +
                ", moduleId='" + moduleId + '\'' +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", task='" + task + '\'' +
                '}';
    }
}