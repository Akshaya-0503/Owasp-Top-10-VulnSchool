package com.cyberdojo;

public class SpringApplication {

}
