package com.cyberdojo.controller;

import com.cyberdojo.model.Module;
import com.cyberdojo.model.Lab;
import com.cyberdojo.repository.ModuleRepository;
import com.cyberdojo.repository.LabRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/content")
@CrossOrigin(origins = "http://localhost:5173")
public class ContentController {

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    private LabRepository labRepository;

    // Get all modules
    @GetMapping("/modules")
    public ResponseEntity<List<Module>> getAllModules() {
        return ResponseEntity.ok(moduleRepository.findAll());
    }

    // Get single module by ID
    @GetMapping("/modules/{id}")
    public ResponseEntity<Module> getModule(@PathVariable String id) {
        Optional<Module> module = moduleRepository.findById(id);
        return module.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get labs for a module
    @GetMapping("/modules/{moduleId}/labs")
    public ResponseEntity<List<Lab>> getLabsForModule(@PathVariable String moduleId) {
        return ResponseEntity.ok(labRepository.findByModuleId(moduleId));
    }
}