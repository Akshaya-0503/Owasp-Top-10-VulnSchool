package com.cyberdojo.controller;

public @interface Nullable {

}
