package com.cyberdojo.controller;

public class Lab {

}
