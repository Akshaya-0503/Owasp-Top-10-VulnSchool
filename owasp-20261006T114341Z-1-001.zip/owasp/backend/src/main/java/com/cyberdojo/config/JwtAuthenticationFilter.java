package com.cyberdojo.config;

public class JwtAuthenticationFilter {
    
}
