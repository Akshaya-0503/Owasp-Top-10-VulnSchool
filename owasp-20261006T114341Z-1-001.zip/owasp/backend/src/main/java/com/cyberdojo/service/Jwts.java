package com.cyberdojo.service;

public class Jwts {

    public static Object parserBuilder() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'parserBuilder'");
    }

}
