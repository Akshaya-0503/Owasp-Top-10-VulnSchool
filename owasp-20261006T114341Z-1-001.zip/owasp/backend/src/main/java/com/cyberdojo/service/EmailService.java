package com.cyberdojo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendPasswordResetEmail(String to, String token) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject("🔐 CyberDojo - Password Reset Request");
            message.setText(
                    "Hello!\n\n" +
                            "We received a request to reset your password for CyberDojo.\n\n" +
                            "Click the link below to reset your password (valid for 1 hour):\n" +
                            "http://localhost:5173/reset-password?token=" + token + "\n\n" +
                            "Or use this token: " + token + "\n\n" +
                            "If you didn't request this, please ignore this email.\n\n" +
                            "Stay Secure,\n" +
                            "CyberDojo Team");
            mailSender.send(message);
            System.out.println("✅ Password reset email sent to: " + to);
        } catch (Exception e) {
            System.err.println("❌ Failed to send email: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void sendWelcomeEmail(String to, String name) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject("🎉 Welcome to CyberDojo!");
            message.setText(
                    "Hi " + name + "!\n\n" +
                            "Welcome to CyberDojo - Your journey to mastering OWASP Top 10 starts here!\n\n" +
                            "Get started by exploring our modules and hands-on labs.\n\n" +
                            "📚 What's next?\n" +
                            "• Complete the Broken Access Control module\n" +
                            "• Try the interactive labs\n" +
                            "• Track your progress\n\n" +
                            "Happy Learning!\n" +
                            "CyberDojo Team");
            mailSender.send(message);
            System.out.println("✅ Welcome email sent to: " + to);
        } catch (Exception e) {
            System.err.println("❌ Failed to send welcome email: " + e.getMessage());
        }
    }
}