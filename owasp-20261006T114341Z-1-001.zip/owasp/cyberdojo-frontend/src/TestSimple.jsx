function TestSimple() {
    return (
        <div style={{
            backgroundColor: '#0a0a0a',
            minHeight: '100vh',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'column',
            color: '#00ff88'
        }}>
            <h1>CyberDojo</h1>
            <p>If you see this, React is working!</p>
            <button onClick={() => window.location.href = '/login'}>
                Go to Login
            </button>
        </div>
    )
}

export default TestSimple