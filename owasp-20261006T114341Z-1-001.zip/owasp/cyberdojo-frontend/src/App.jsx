import { Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Dashboard from './pages/Dashboard'
import ModuleDetail from './pages/ModuleDetail'
import Profile from './pages/Profile'
import ChangePassword from './pages/ChangePassword'
import Progress from './pages/Progress'
import Navbar from './components/Navbar'

function App() {
  const [isAuth, setIsAuth] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token && token !== 'undefined') {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setIsAuth(true)
    }
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div style={{ height: '100vh', background: '#0a0a0a', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="spinner-border text-success"></div>
      </div>
    )
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      <Route path="/dashboard" element={
        isAuth ? (
          <>
            <Navbar />
            <Dashboard />
          </>
        ) : (
          <Navigate to="/login" />
        )
      } />

      <Route path="/profile" element={
        isAuth ? (
          <>
            <Navbar />
            <Profile />
          </>
        ) : (
          <Navigate to="/login" />
        )
      } />

      <Route path="/change-password" element={
        isAuth ? (
          <>
            <Navbar />
            <ChangePassword />
          </>
        ) : (
          <Navigate to="/login" />
        )
      } />

      <Route path="/progress" element={
        isAuth ? (
          <>
            <Navbar />
            <Progress />
          </>
        ) : (
          <Navigate to="/login" />
        )
      } />

      <Route path="/module/:id" element={
        isAuth ? (
          <>
            <Navbar />
            <ModuleDetail />
          </>
        ) : (
          <Navigate to="/login" />
        )
      } />

      <Route path="/" element={
        isAuth ? <Navigate to="/dashboard" /> : <Navigate to="/login" />
      } />
    </Routes>
  )
}

export default App