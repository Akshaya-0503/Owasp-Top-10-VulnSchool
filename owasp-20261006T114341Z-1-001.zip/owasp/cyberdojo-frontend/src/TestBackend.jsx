import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

function TestBackend() {
    const [result, setResult] = useState('')
    const [loading, setLoading] = useState(false)

    const testRegister = async () => {
        setLoading(true)
        try {
            const response = await fetch('http://localhost:8080/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: 'Test User',
                    email: `test${Date.now()}@example.com`,
                    password: 'test123'
                })
            })
            const data = await response.json()
            setResult(JSON.stringify(data, null, 2))
        } catch (error) {
            setResult('Error: ' + error.message)
        }
        setLoading(false)
    }

    const testLogin = async () => {
        setLoading(true)
        try {
            const response = await fetch('http://localhost:8080/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: 'test@example.com',
                    password: 'test123'
                })
            })
            const data = await response.json()
            setResult(JSON.stringify(data, null, 2))
        } catch (error) {
            setResult('Error: ' + error.message)
        }
        setLoading(false)
    }

    return (
        <div className="container mt-5">
            <div className="card">
                <div className="card-header bg-primary text-white">
                    <h3>Backend Connection Test</h3>
                </div>
                <div className="card-body">
                    <div className="mb-3">
                        <p><strong>Backend URL:</strong> http://localhost:8080</p>
                        <p><strong>Status:</strong> <span className="text-success">✅ Should be running</span></p>
                    </div>

                    <div className="d-flex gap-3 mb-4">
                        <button
                            className="btn btn-primary"
                            onClick={testRegister}
                            disabled={loading}
                        >
                            {loading ? 'Testing...' : 'Test Register'}
                        </button>
                        <button
                            className="btn btn-success"
                            onClick={testLogin}
                            disabled={loading}
                        >
                            {loading ? 'Testing...' : 'Test Login'}
                        </button>
                    </div>

                    {result && (
                        <div className="mt-3">
                            <h5>Response:</h5>
                            <pre className="bg-light p-3 rounded" style={{ overflowX: 'auto' }}>
                                {result}
                            </pre>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

export default TestBackend