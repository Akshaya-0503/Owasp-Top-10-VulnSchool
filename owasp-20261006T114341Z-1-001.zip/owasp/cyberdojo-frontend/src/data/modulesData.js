export const modulesData = {
    'A01': {
        id: 'A01',
        title: 'Broken Access Control',
        difficulty: 'Medium',
        cvss: '7.5',
        story: {
            hook: "🎬 Imagine changing a number in your browser URL and seeing someone else's bank account!",
            scenario: "Meet Sarah, a regular bank customer. She noticed her URL: bank.com/account?id=12345. Changing it to 12346 showed a stranger's complete financial history.",
            realWorld: "🔴 REAL WORLD: In 2022, a major healthcare provider exposed 1.2 million patient records.",
            what: "Broken Access Control happens when an application doesn't properly check permissions.",
            why: "Developers often forget to add authorization checks.",
            prevention: "1️⃣ Always verify user permissions\n2️⃣ Use server-side session management\n3️⃣ Implement RBAC\n4️⃣ Never trust client-side data\n5️⃣ Regular security audits"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - No access control\napp.get('/api/user/:id', (req, res) => {\n  const user = db.findUser(req.params.id);\n  res.json(user);\n});`,
            secure: `// SECURE - With access control\napp.get('/api/user/:id', auth, (req, res) => {\n  if (req.user.id !== req.params.id) {\n    return res.status(403).json({ error: 'Access denied' });\n  }\n  const user = db.findUser(req.params.id);\n  res.json(user);\n});`
        }
    },
    'A02': {
        id: 'A02',
        title: 'Security Misconfiguration',
        difficulty: 'Easy',
        cvss: '6.5',
        story: {
            hook: "🏢 Leaving default passwords and debug mode on in production!",
            scenario: "A company left debug mode ON in production, exposing database credentials.",
            realWorld: "🔴 REAL WORLD: Major tech company exposed 100M records due to misconfiguration.",
            what: "Using insecure default settings.",
            why: "Rushed deployments, no security review.",
            prevention: "1️⃣ Remove default credentials\n2️⃣ Disable debug mode\n3️⃣ Regular security headers"
        },
        codeExample: {
            vulnerable: `# VULNERABLE - Debug mode ON\nDEBUG = True\nSECRET_KEY = 'default-key'`,
            secure: `# SECURE - Production config\nDEBUG = False\nSECRET_KEY = os.environ.get('SECRET_KEY')`
        }
    },
    'A03': {
        id: 'A03',
        title: 'Injection',
        difficulty: 'Medium',
        cvss: '9.0',
        story: {
            hook: "💉 Typing ' OR 1=1 -- could empty a company's entire database!",
            scenario: "A student typed malicious SQL and deleted the entire database.",
            realWorld: "🔴 REAL WORLD: Yahoo breach (2014) started with SQL injection.",
            what: "Attackers inject malicious code into queries.",
            why: "Using user input directly in database queries.",
            prevention: "1️⃣ Use parameterized queries\n2️⃣ Input validation\n3️⃣ Use ORM frameworks"
        },
        codeExample: {
            vulnerable: `# VULNERABLE - String concatenation\nquery = f"SELECT * FROM users WHERE name = '{user_input}'"`,
            secure: `# SECURE - Parameterized query\ncursor.execute("SELECT * FROM users WHERE name = %s", (user_input,))`
        }
    },
    'A04': {
        id: 'A04',
        title: 'Cryptographic Failures',
        difficulty: 'Medium',
        cvss: '7.4',
        story: {
            hook: "🔐 You send a secret love letter in a transparent envelope!",
            scenario: "A popular shopping site stored passwords in plain text.",
            realWorld: "🔴 REAL WORLD: Equifax breach (2017) exposed 147 million records.",
            what: "Sensitive data is not properly encrypted.",
            why: "Using weak algorithms or not encrypting at all.",
            prevention: "1️⃣ Use AES-256 for encryption\n2️⃣ Use bcrypt for passwords\n3️⃣ Never roll your own crypto"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - MD5 is broken!\nconst hash = crypto.createHash('md5').update(password).digest('hex');`,
            secure: `// SECURE - Use bcrypt\nconst hash = await bcrypt.hash(password, 12);`
        }
    },
    'A05': {
        id: 'A05',
        title: 'Cross-Site Scripting (XSS)',
        difficulty: 'Medium',
        cvss: '9.0',
        story: {
            hook: "🌐 What if a comment on a website could steal your login cookies?",
            scenario: "A popular forum allowed users to post HTML comments.",
            realWorld: "🔴 REAL WORLD: MySpace Samy worm infected 1 million users.",
            what: "Attackers inject malicious scripts into web pages.",
            why: "Not sanitizing user input before displaying it.",
            prevention: "1️⃣ Output encoding\n2️⃣ Content Security Policy\n3️⃣ Input sanitization"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - Direct output\n<div dangerouslySetInnerHTML={{__html: userComment}} />`,
            secure: `// SECURE - Sanitized output\n<div dangerouslySetInnerHTML={{__html: DOMPurify.sanitize(userComment)}} />`
        }
    },
    'A06': {
        id: 'A06',
        title: 'Insecure Design',
        difficulty: 'Hard',
        cvss: '7.1',
        story: {
            hook: "🏗️ Building a house with no doors is bad design!",
            scenario: "Password reset didn't verify user identity.",
            realWorld: "🔴 REAL WORLD: Instagram had a vulnerability in password reset.",
            what: "Security flaws at the design level.",
            why: "Security as an afterthought.",
            prevention: "1️⃣ Threat modeling\n2️⃣ Security requirements\n3️⃣ Secure design patterns"
        },
        codeExample: {
            vulnerable: `// VULNERABLE DESIGN\nfunction resetPassword(email) {\n    sendResetLink(email);\n}`,
            secure: `// SECURE DESIGN\nfunction resetPassword(email) {\n    multiFactorVerification(email);\n}`
        }
    },
    'A07': {
        id: 'A07',
        title: 'Authentication Failures',
        difficulty: 'Easy',
        cvss: '8.1',
        story: {
            hook: "🔑 Using 'password123' is bad. Allowing it is worse!",
            scenario: "No rate limiting allowed brute force attacks.",
            realWorld: "🔴 REAL WORLD: Credential stuffing attacks on streaming services.",
            what: "Weak authentication mechanisms.",
            why: "No MFA, weak password policies.",
            prevention: "1️⃣ Implement MFA\n2️⃣ Rate limiting\n3️⃣ Account lockout"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - No rate limiting\nfunction login(username, password) {\n    return user.password === password;\n}`,
            secure: `// SECURE - With rate limiting\nif (failedAttempts > 5) return "Account locked";`
        }
    },
    'A08': {
        id: 'A08',
        title: 'Software Integrity Failures',
        difficulty: 'Hard',
        cvss: '7.8',
        story: {
            hook: "🔄 What if your software update was actually malware?",
            scenario: "CDN compromise led to malicious updates.",
            realWorld: "🔴 REAL WORLD: SolarWinds attack compromised thousands of companies.",
            what: "Failing to verify software integrity.",
            why: "No integrity checks.",
            prevention: "1️⃣ Code signing\n2️⃣ Integrity hashes\n3️⃣ Subresource Integrity"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - No integrity check\n<script src="https://cdn.example.com/lib.js"></script>`,
            secure: `// SECURE - With integrity hash\n<script src="https://cdn.example.com/lib.js" integrity="sha384-..." crossorigin></script>`
        }
    },
    'A09': {
        id: 'A09',
        title: 'Security Logging Failures',
        difficulty: 'Medium',
        cvss: '6.8',
        story: {
            hook: "📝 If a tree falls and no one hears it, did it happen?",
            scenario: "Company was hacked for 6 months before noticing.",
            realWorld: "🔴 REAL WORLD: Uber breach discovered via Slack post.",
            what: "No proper logging and monitoring.",
            why: "Logs turned off for performance.",
            prevention: "1️⃣ Log all auth attempts\n2️⃣ Centralized logging\n3️⃣ Real-time alerts"
        },
        codeExample: {
            vulnerable: `// VULNERABLE - Minimal logging\ntry {\n    processPayment();\n} catch(e) {\n    console.log("Error");\n}`,
            secure: `// SECURE - Comprehensive logging\nlogger.error({\n    event: 'PAYMENT_FAILURE',\n    user: currentUser.id,\n    error: e.message\n});`
        }
    },
    'A10': {
        id: 'A10',
        title: 'Exception Handling',
        difficulty: 'Medium',
        cvss: '6.2',
        story: {
            hook: "💥 What happens when your app faces the unexpected?",
            scenario: "Banking app crashed revealing database credentials.",
            realWorld: "🔴 REAL WORLD: Airline website showed stack traces.",
            what: "Revealing sensitive info through errors.",
            why: "Not handling edge cases.",
            prevention: "1️⃣ Custom error pages\n2️⃣ Graceful degradation\n3️⃣ Don't leak internal details"
        },
        codeExample: {
            vulnerable: `# VULNERABLE - Shows internal errors\n@app.route('/user/<int:id>')\ndef get_user(id):\n    user = database.execute(f"SELECT * FROM users WHERE id = {id}")`,
            secure: `# SECURE - Handles errors\ntry:\n    user = get_user_by_id(id)\n    return user if user else {"error": "Not found"}\nexcept Exception:\n    return {"error": "Internal error"}`
        }
    }
}

export const getModuleContent = (moduleId) => {
    return modulesData[moduleId] || null
}