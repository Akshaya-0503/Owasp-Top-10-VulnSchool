export const labsData = {
    'A01': [
        {
            id: 'idor-lab-1',
            title: 'IDOR - Insecure Direct Object Reference',
            type: 'idor',
            description: 'A banking application displays account details based on account number in URL. Can you access another user\'s account?',
            endpoint: 'GET /api/account/{accountId}',
            task: 'Access account #1002 without authorization',
            examplePayload: '1002',
            hint: 'Try changing the account ID in the URL parameter. Your account is #1001, try #1002',
            impact: 'Access to other users\' financial data',
            dataExtracted: 'Account balance: $15,000',
            vulnerableCode: `// Vulnerable endpoint\napp.get('/api/account/:id', (req, res) => {\n  const account = accounts.find(a => a.id === req.params.id);\n  res.json(account);\n});`,
            secureCode: `// Secure version\napp.get('/api/account/:id', auth, (req, res) => {\n  if (req.user.accountId !== req.params.id) {\n    return res.status(403).json({ error: 'Access denied' });\n  }\n  const account = accounts.find(a => a.id === req.params.id);\n  res.json(account);\n});`
        }
    ],
    'A02': [
        {
            id: 'security-misconfig-1',
            title: 'Security Misconfiguration',
            type: 'security-misconfig',
            description: 'Application running in debug mode exposes sensitive error information',
            endpoint: 'GET /error',
            task: 'Find the hidden admin panel',
            examplePayload: '/admin',
            hint: 'Try accessing common admin paths like /admin, /dashboard, /panel',
            impact: 'Exposure of database credentials, API keys, and internal paths',
            dataExtracted: 'DATABASE_URL=postgresql://admin:password123@localhost:5432/app',
            vulnerableCode: `# Debug mode enabled in production\nDEBUG = True\nSECRET_KEY = 'hardcoded-secret-key'`,
            secureCode: `# Debug mode disabled in production\nDEBUG = False\nSECRET_KEY = os.environ.get('SECRET_KEY')`
        }
    ],
    'A03': [
        {
            id: 'sql-injection-1',
            title: 'SQL Injection - Login Bypass',
            type: 'sql-injection',
            description: 'Login form vulnerable to SQL injection. Can you login as admin?',
            endpoint: 'POST /login',
            task: 'Bypass authentication and login as admin without password',
            examplePayload: "admin' --",
            hint: "Try: admin' -- or ' OR '1'='1",
            impact: 'Unauthorized access to admin accounts, data theft, account takeover',
            dataExtracted: 'Admin credentials: admin@example.com (password hash: 5f4dcc3b5aa765d61d8327deb882cf99)',
            vulnerableCode: `// Vulnerable SQL query\nconst query = "SELECT * FROM users WHERE username='" + username + "' AND password='" + password + "'";\ndb.query(query);`,
            secureCode: `// Secure parameterized query\nconst query = "SELECT * FROM users WHERE username = ? AND password = ?";\ndb.query(query, [username, password]);`
        }
    ],
    'A04': [
        {
            id: 'crypto-1',
            title: 'Weak Cryptography - Hash Cracking',
            type: 'crypto',
            description: 'Passwords stored using weak MD5 hashing',
            endpoint: 'GET /users',
            task: 'Crack the MD5 hash to reveal the password',
            examplePayload: '5f4dcc3b5aa765d61d8327deb882cf99',
            hint: 'This hash corresponds to a very common password (5 characters)',
            impact: 'Password compromise, account takeover',
            dataExtracted: 'Hash cracked: "password" - Account compromised!',
            vulnerableCode: `// Weak MD5 hashing\nconst hash = crypto.createHash('md5').update(password).digest('hex');`,
            secureCode: `// Strong bcrypt hashing\nconst hash = await bcrypt.hash(password, 12);`
        }
    ],
    'A05': [
        {
            id: 'xss-1',
            title: 'Reflected XSS - Script Injection',
            type: 'xss-reflected',
            description: 'Search box reflects user input without sanitization',
            endpoint: 'GET /search?q=<script>',
            task: 'Execute JavaScript code through the search parameter',
            examplePayload: "<script>alert('XSS')</script>",
            hint: "Use <script> tags or event handlers like onerror=",
            impact: 'Session hijacking, credential theft, defacement, phishing',
            dataExtracted: 'document.cookie: "session=eyJ1c2VyIjoiYWRtaW4ifQ"',
            vulnerableCode: `// Vulnerable output\n<h1>Search results for: {searchQuery}</h1>`,
            secureCode: `// Secure with output encoding\n<h1>Search results for: {escape(searchQuery)}</h1>`
        }
    ],
    'A06': [
        {
            id: 'priv-esc-1',
            title: 'Privilege Escalation',
            type: 'privilege-escalation',
            description: 'API accepts role parameter from client side',
            endpoint: 'POST /api/user/update',
            task: 'Escalate your privileges to admin',
            examplePayload: 'role=admin',
            hint: 'Look for parameters that control user roles or permissions',
            impact: 'Full system access, data modification, user management',
            dataExtracted: 'Admin privileges granted! You can now access all system features',
            vulnerableCode: `// Trusts client-provided role\nuser.role = req.body.role || 'user';`,
            secureCode: `// Server determines role\nuser.role = 'user';  // Never trust client input for permissions`
        }
    ],
    'A07': [
        {
            id: 'auth-1',
            title: 'Authentication Failure - Brute Force',
            type: 'brute-force',
            description: 'Login system has no rate limiting or account lockout',
            endpoint: 'POST /login',
            task: 'Find the admin password using brute force',
            examplePayload: 'admin123',
            hint: 'Try common passwords: admin, password, 123456, qwerty, admin123',
            impact: 'Account takeover, unauthorized access to admin panel',
            dataExtracted: 'Admin password: "admin123" - Account compromised!',
            vulnerableCode: `// No rate limiting\nfunction login(username, password) {\n  const user = findUser(username);\n  return user && user.password === password;\n}`,
            secureCode: `// With rate limiting\nconst failedAttempts = new Map();\nfunction login(username, password) {\n  if (failedAttempts.get(username) >= 5) {\n    return 'Account locked';\n  }\n  // Validate credentials...\n}`
        }
    ],
    'A08': [
        {
            id: 'integrity-1',
            title: 'Data Integrity Failure',
            type: 'integrity-failure',
            description: 'Software updates without integrity verification',
            endpoint: 'GET /update',
            task: 'Find how to verify software integrity',
            examplePayload: 'checksum',
            hint: 'Look for SHA256 or MD5 hash verification',
            impact: 'Malicious code injection, supply chain attack',
            dataExtracted: 'Integrity check bypassed - Malicious code injected',
            vulnerableCode: `// No integrity verification\nconst update = await fetch('https://cdn.example.com/update.tar.gz');\ninstall(update);`,
            secureCode: `// With integrity verification\nconst update = await fetch('https://cdn.example.com/update.tar.gz');\nconst hash = crypto.createHash('sha256').update(update).digest('hex');\nif (hash === EXPECTED_HASH) install(update);`
        }
    ],
    'A09': [
        {
            id: 'logging-1',
            title: 'Logging and Monitoring Failure',
            type: 'logging-failure',
            description: 'Application doesn\'t log security events properly',
            endpoint: 'POST /api/login',
            task: 'Identify what should be logged',
            examplePayload: 'Failed login attempts',
            hint: 'Think about what security events need to be monitored',
            impact: 'Cannot detect attacks, delayed incident response',
            dataExtracted: 'Attack went undetected for 30 days',
            vulnerableCode: `// No logging\nfunction login(username, password) {\n  if (authenticate(username, password)) return 'Success';\n  return 'Failed';\n}`,
            secureCode: `// Proper logging\nfunction login(username, password) {\n  logger.info('Login attempt for: ' + username);\n  if (authenticate(username, password)) {\n    logger.info('Successful login for: ' + username);\n    return 'Success';\n  }\n  logger.warning('Failed login for: ' + username);\n  return 'Failed';\n}`
        }
    ],
    'A10': [
        {
            id: 'exception-1',
            title: 'Exception Handling',
            type: 'exception-handling',
            description: 'Application reveals stack traces on error',
            endpoint: 'GET /api/user/999999',
            task: 'Trigger an error that reveals database structure',
            examplePayload: '999999',
            hint: 'Access a resource that doesn\'t exist or send invalid data',
            impact: 'Database schema exposure, internal paths revealed',
            dataExtracted: 'SQL Query: SELECT * FROM users WHERE id = 999999\nDatabase: MySQL 8.0',
            vulnerableCode: `// Reveals detailed errors\ntry {\n  const user = db.findUser(id);\n} catch (e) {\n  return e.message;  // Shows full error details\n}`,
            secureCode: `// Generic error messages\ntry {\n  const user = db.findUser(id);\n} catch {\n  return 'An error occurred';\n}`
        }
    ]
}

export const getLabsForModule = (moduleId) => {
    return labsData[moduleId] || []
}