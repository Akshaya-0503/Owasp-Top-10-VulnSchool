const API_BASE_URL = 'http://localhost:8080/api';

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Get current user from localStorage
export const getCurrentUser = () => {
    try {
        const user = localStorage.getItem('user');
        if (user && user !== 'undefined' && user !== 'null') {
            return JSON.parse(user);
        }
        return null;
    } catch (error) {
        console.error('Error getting current user:', error);
        return null;
    }
};

// Get auth token
export const getAuthToken = () => {
    return localStorage.getItem('token');
};

// Check if user is authenticated
export const isAuthenticated = () => {
    const token = getAuthToken();
    const user = getCurrentUser();
    return token && token !== 'undefined' && token !== 'null' && user;
};

// ============================================
// AUTHENTICATION APIs
// ============================================

// Register new user
export const register = async (name, email, password) => {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, password }),
        });
        const data = await response.json();
        console.log('Register response:', data);
        return data;
    } catch (error) {
        console.error('Register error:', error);
        return { success: false, message: 'Network error - Is backend running on port 8080?' };
    }
};

// Login user
export const login = async (email, password) => {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });
        const data = await response.json();
        console.log('Login response:', data);

        if (data.success && data.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            console.log('User logged in:', data.user);
        }
        return data;
    } catch (error) {
        console.error('Login error:', error);
        return { success: false, message: 'Network error - Is backend running on port 8080?' };
    }
};

// Logout user
export const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    console.log('User logged out');
};

// Get current user info from backend
export const getCurrentUserInfo = async () => {
    try {
        const token = getAuthToken();
        if (!token) {
            return { success: false };
        }

        const response = await fetch(`${API_BASE_URL}/auth/me`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Get user info error:', error);
        return { success: false };
    }
};

// Change password
export const changePassword = async (currentPassword, newPassword) => {
    try {
        const token = getAuthToken();
        if (!token) {
            return { success: false, message: 'Not authenticated' };
        }

        const response = await fetch(`${API_BASE_URL}/auth/change-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({ currentPassword, newPassword }),
        });
        const data = await response.json();
        console.log('Change password response:', data);
        return data;
    } catch (error) {
        console.error('Change password error:', error);
        return { success: false, message: 'Network error' };
    }
};

// Forgot password - Request reset token
export const forgotPassword = async (email) => {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email }),
        });
        const data = await response.json();
        console.log('Forgot password response:', data);
        return data;
    } catch (error) {
        console.error('Forgot password error:', error);
        return { message: 'Network error' };
    }
};

// Reset password using token
export const resetPassword = async (token, newPassword) => {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/reset-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token, newPassword }),
        });
        const data = await response.json();
        console.log('Reset password response:', data);
        return data;
    } catch (error) {
        console.error('Reset password error:', error);
        return { success: 'false', message: 'Network error' };
    }
};

// ============================================
// PROGRESS APIs (User-specific)
// ============================================

// Get user progress from BACKEND
export const getUserProgress = async () => {
    try {
        const token = getAuthToken();
        if (!token) {
            console.log('No token found');
            return { success: false, progress: {} };
        }

        const response = await fetch(`${API_BASE_URL}/progress/my-progress`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
        });

        const data = await response.json();
        console.log('Get progress from backend:', data);

        if (data.success) {
            return { success: true, progress: data.progress || {} };
        }
        return { success: false, progress: {} };
    } catch (error) {
        console.error('Get progress error:', error);
        return { success: false, progress: {} };
    }
};

// Update module progress to BACKEND
export const updateModuleProgress = async (moduleId, status, completedLabs = []) => {
    try {
        const token = getAuthToken();
        if (!token) {
            console.log('No token found');
            return { success: false };
        }

        const response = await fetch(`${API_BASE_URL}/progress/update`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
                moduleId,
                status,
                completedLabs
            }),
        });

        const data = await response.json();
        console.log('Update progress to backend:', data);
        return data;
    } catch (error) {
        console.error('Update progress error:', error);
        return { success: false };
    }
};

// ============================================
// CONTENT APIs (Database)
// ============================================

// Get all modules from database
export const getAllModules = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/content/modules`);
        const data = await response.json();
        console.log('Get modules:', data.length);
        return data;
    } catch (error) {
        console.error('Get modules error:', error);
        return [];
    }
};

// Get single module by ID
export const getModuleById = async (moduleId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/content/modules/${moduleId}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Get module error:', error);
        return null;
    }
};

// Get labs for a module
export const getLabsByModuleId = async (moduleId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/content/modules/${moduleId}/labs`);
        const data = await response.json();
        console.log(`Get labs for ${moduleId}:`, data.length);
        return data;
    } catch (error) {
        console.error('Get labs error:', error);
        return [];
    }
};

// ============================================
// LOCAL STORAGE HELPERS (Fallback)
// ============================================

// Save progress to localStorage (fallback when backend is down)
export const saveProgressToLocal = (userId, moduleId, status, completedLabs) => {
    try {
        const key = `moduleProgress_${userId}`;
        const existing = JSON.parse(localStorage.getItem(key) || '{}');
        existing[moduleId] = {
            status: status,
            completedLabs: completedLabs,
            lastUpdated: new Date().toISOString()
        };
        localStorage.setItem(key, JSON.stringify(existing));
        console.log('Progress saved to localStorage');
        return true;
    } catch (error) {
        console.error('Error saving to localStorage:', error);
        return false;
    }
};

// Load progress from localStorage (fallback)
export const loadProgressFromLocal = (userId) => {
    try {
        const key = `moduleProgress_${userId}`;
        const saved = localStorage.getItem(key);
        if (saved) {
            return JSON.parse(saved);
        }
        return {};
    } catch (error) {
        console.error('Error loading from localStorage:', error);
        return {};
    }
};

// ============================================
// DEMO MODE (For testing without backend)
// ============================================

// Demo login (local only)
export const demoLogin = async (email, password) => {
    // Demo users for testing
    const demoUsers = [
        { id: 1, name: 'Demo User', email: 'demo@vulnschool.com', password: 'demo123' },
        { id: 2, name: 'Test Student', email: 'test@student.com', password: 'test123' },
        { id: 3, name: 'John Doe', email: 'john@example.com', password: 'john123' }
    ];

    const user = demoUsers.find(u => u.email === email && u.password === password);

    if (user) {
        localStorage.setItem('token', 'demo-token-' + Date.now());
        localStorage.setItem('user', JSON.stringify({ id: user.id, name: user.name, email: user.email }));
        return { success: true, user: { name: user.name, email: user.email } };
    }
    return { success: false, message: 'Invalid credentials' };
};

// Demo register (local only)
export const demoRegister = async (name, email, password) => {
    const newUser = {
        id: Date.now(),
        name: name,
        email: email,
        password: password
    };
    localStorage.setItem('demoUser', JSON.stringify(newUser));
    return { success: true, message: 'Registration successful!' };
};

// ============================================
// EXPORTS
// ============================================

export default {
    // Auth
    register,
    login,
    logout,
    isAuthenticated,
    getCurrentUser,
    getAuthToken,
    getCurrentUserInfo,
    changePassword,
    forgotPassword,
    resetPassword,

    // Progress
    getUserProgress,
    updateModuleProgress,
    saveProgressToLocal,
    loadProgressFromLocal,

    // Content
    getAllModules,
    getModuleById,
    getLabsByModuleId,

    // Demo
    demoLogin,
    demoRegister
};