import { useState } from 'react'
import { Card, Button, Alert, Form, Badge, ProgressBar, Modal } from 'react-bootstrap'
import { FaCode, FaShieldAlt, FaTerminal, FaLightbulb, FaCheck, FaSkull, FaPlay } from 'react-icons/fa'
import { FiRefreshCw } from 'react-icons/fi'
import './LabEnvironment.css'

function LabEnvironment({ lab, onComplete, isCompleted }) {
    const [userInput, setUserInput] = useState('')
    const [feedback, setFeedback] = useState(null)
    const [showHint, setShowHint] = useState(false)
    const [attempts, setAttempts] = useState(0)
    const [showSuccessModal, setShowSuccessModal] = useState(false)
    const [showVulnerableModal, setShowVulnerableModal] = useState(false)
    const [terminalOutput, setTerminalOutput] = useState('')
    const [isExecuting, setIsExecuting] = useState(false)

    const validateAnswer = (input, labType) => {
        const normalizedInput = input.toLowerCase().trim()

        const validations = {
            'idor': () => normalizedInput === '1002' || normalizedInput === '2' || normalizedInput.includes('user/2'),
            'sql-injection': () => /' or '1'='1/.test(normalizedInput) || /admin' --/.test(normalizedInput),
            'xss-reflected': () => /<script>/.test(normalizedInput) || /onerror=/.test(normalizedInput),
            'xss-stored': () => /<script>/.test(normalizedInput) || /<img/.test(normalizedInput),
            'path-traversal': () => /\.\.\/\.\.\/etc\/passwd/.test(normalizedInput),
            'privilege-escalation': () => normalizedInput.includes('admin'),
            'crypto': () => normalizedInput === 'password' || normalizedInput === '5f4dcc3b5aa765d61d8327deb882cf99',
            'brute-force': () => ['admin', 'password', '123456', 'admin123', 'letmein'].includes(normalizedInput),
            'cmd-injection': () => /; ls/.test(normalizedInput) || /&& whoami/.test(normalizedInput),
            'security-misconfig': () => normalizedInput.includes('/admin') || normalizedInput.includes('/backup'),
            'auth-failure': () => normalizedInput === 'admin' || normalizedInput === 'administrator',
            'integrity-failure': () => normalizedInput.includes('checksum') || normalizedInput.includes('hash'),
            'logging-failure': () => normalizedInput.includes('log') || normalizedInput.includes('alert'),
            'exception-handling': () => normalizedInput.includes('error') || normalizedInput.includes('stack')
        }

        return validations[labType] ? validations[labType]() : false
    }

    const handleSubmit = () => {
        if (!userInput.trim()) {
            setFeedback({ type: 'warning', message: '⚠️ Please enter a payload to test the vulnerability!' })
            return
        }

        const newAttempts = attempts + 1
        setAttempts(newAttempts)

        if (validateAnswer(userInput, lab.type)) {
            setFeedback({ type: 'success', message: '🎉 Perfect! You successfully exploited the vulnerability!' })
            setShowSuccessModal(true)
            setTerminalOutput(`[+] Exploit successful!\n[+] Payload: ${userInput}\n[+] Vulnerability exploited!\n[+] Flag captured!`)

            // Call onComplete IMMEDIATELY to update parent
            onComplete(lab.id)

            setTimeout(() => {
                setShowSuccessModal(false)
            }, 2000)
        } else {
            setFeedback({ type: 'danger', message: '❌ Exploit failed! The vulnerability still exists. Try again!' })
            setTerminalOutput(`[-] Exploit failed!\n[-] Payload: ${userInput}\n[-] Reason: Input was sanitized or invalid\n[-] Try a different approach`)
            if (newAttempts >= 3) {
                setShowVulnerableModal(true)
            }
        }
    }

    const runSimulation = () => {
        setIsExecuting(true)
        setTerminalOutput('')

        setTimeout(() => {
            let output = ''
            if (validateAnswer(userInput, lab.type)) {
                output = `┌─────────────────────────────────────┐\n│      EXPLOIT SIMULATION v2.0        │\n├─────────────────────────────────────┤\n│ [✓] Payload: ${userInput}\n│ [✓] Status: SUCCESS\n│ [✓] Impact: ${lab.impact}\n│ [✓] Data: ${lab.dataExtracted || 'Sensitive data compromised'}\n└─────────────────────────────────────┘\n\n[+] Vulnerability confirmed!\n[+] Recommended Fix: Use input validation and sanitization`
            } else {
                output = `┌─────────────────────────────────────┐\n│      EXPLOIT SIMULATION v2.0        │\n├─────────────────────────────────────┤\n│ [✗] Payload: ${userInput}\n│ [✗] Status: FAILED\n│ [✗] Reason: Input validation detected\n│ [✗] Suggestion: ${lab.hint.substring(0, 50)}\n└─────────────────────────────────────┘`
            }
            setTerminalOutput(output)
            setIsExecuting(false)
        }, 1000)
    }

    const resetLab = () => {
        setUserInput('')
        setFeedback(null)
        setTerminalOutput('')
        setShowHint(false)
        setAttempts(0)
        localStorage.removeItem(`lab_${lab.id}_attempts`)

        // Reload to refresh UI
        window.location.reload()
    }

    return (
        <>
            <Card className={`lab-environment ${isCompleted ? 'completed' : ''}`}>
                <Card.Header className={isCompleted ? 'bg-success' : 'bg-dark'}>
                    <div className="d-flex justify-content-between align-items-center flex-wrap">
                        <div className="text-white">
                            <FaTerminal className="me-2" />
                            <strong>Interactive Lab:</strong> {lab.title}
                        </div>
                        <div className="mt-2 mt-sm-0">
                            {isCompleted && <Badge bg="success" className="p-2"><FaCheck className="me-1" /> Completed</Badge>}
                            {!isCompleted && attempts > 0 && <Badge bg="warning" className="p-2">Attempts: {attempts}/3</Badge>}
                        </div>
                    </div>
                </Card.Header>

                <Card.Body>
                    <div className="lab-scenario mb-4">
                        <h6 className="text-primary mb-2">📖 Scenario</h6>
                        <p>{lab.description}</p>
                        <div className="mt-2">
                            <strong className="text-info">🎯 Task:</strong> {lab.task}
                        </div>
                        <Alert variant="danger" className="mt-2">
                            <FaSkull className="me-2" />
                            <strong>Vulnerable Endpoint:</strong> {lab.endpoint}
                        </Alert>
                    </div>

                    <div className="vulnerable-code mb-4">
                        <h6 className="text-danger mb-2"><FaCode /> Vulnerable Code</h6>
                        <pre className="bg-dark text-light p-3 rounded">
                            <code>{lab.vulnerableCode}</code>
                        </pre>
                    </div>

                    <div className="lab-terminal mb-4">
                        <h6 className="text-success mb-2"><FaTerminal /> Exploit Terminal</h6>
                        <div className="terminal-window bg-dark rounded p-3">
                            <div className="terminal-header mb-2">
                                <span className="text-light">$ exploit.sh</span>
                            </div>
                            <div className="terminal-body">
                                <div className="d-flex flex-column gap-2">
                                    <div className="d-flex align-items-center">
                                        <span className="text-success me-2">➜</span>
                                        <span className="text-light">Enter your exploit payload:</span>
                                    </div>
                                    <Form.Control
                                        as="textarea"
                                        rows={2}
                                        value={userInput}
                                        onChange={(e) => setUserInput(e.target.value)}
                                        placeholder={`Example: ${lab.examplePayload}`}
                                        className="bg-dark text-light border-secondary font-monospace"
                                        disabled={isCompleted}
                                    />
                                    <div className="d-flex gap-2 mt-2 flex-wrap">
                                        <Button variant="danger" size="sm" onClick={handleSubmit} disabled={isCompleted}>
                                            <FaSkull className="me-1" /> Execute Exploit
                                        </Button>
                                        <Button variant="info" size="sm" onClick={runSimulation} disabled={isCompleted || isExecuting}>
                                            {isExecuting ? <div className="spinner-border spinner-border-sm" /> : <FaPlay className="me-1" />}
                                            {isExecuting ? ' Simulating...' : ' Simulate Attack'}
                                        </Button>
                                        <Button variant="secondary" size="sm" onClick={() => setShowHint(!showHint)}>
                                            <FaLightbulb className="me-1" /> {showHint ? 'Hide Hint' : 'Show Hint'}
                                        </Button>
                                        {!isCompleted && (
                                            <Button variant="outline-secondary" size="sm" onClick={resetLab}>
                                                <FiRefreshCw className="me-1" /> Reset Lab
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {showHint && (
                            <Alert variant="info" className="mt-3">
                                <strong>💡 Exploit Hint:</strong>
                                <p className="mb-0 mt-1">{lab.hint}</p>
                                <hr />
                                <strong>Example Payload:</strong>
                                <code className="d-block mt-1 bg-dark p-2 rounded">{lab.examplePayload}</code>
                            </Alert>
                        )}

                        {terminalOutput && (
                            <Alert variant="dark" className="mt-3">
                                <pre className="mb-0 small text-light" style={{ whiteSpace: 'pre-wrap', fontFamily: 'monospace' }}>
                                    {terminalOutput}
                                </pre>
                            </Alert>
                        )}

                        {feedback && (
                            <Alert variant={feedback.type} className="mt-3">
                                {feedback.message}
                            </Alert>
                        )}
                    </div>

                    {isCompleted && (
                        <div className="secure-code mt-4">
                            <h6 className="text-success mb-2"><FaShieldAlt /> Secure Implementation</h6>
                            <pre className="bg-success bg-opacity-10 p-3 rounded border border-success">
                                <code>{lab.secureCode}</code>
                            </pre>
                            <Alert variant="success">
                                <strong>🎉 Great job!</strong> You've successfully exploited and learned to fix this vulnerability!
                            </Alert>
                        </div>
                    )}

                    {!isCompleted && (
                        <div className="mt-3">
                            <ProgressBar
                                now={Math.min(attempts * 33, 100)}
                                variant={attempts >= 3 ? 'danger' : attempts >= 2 ? 'warning' : 'primary'}
                                className="rounded-pill"
                                style={{ height: '5px' }}
                            />
                            <small className="text-muted">
                                {attempts === 0 ? '💀 Try to exploit the vulnerability' :
                                    attempts === 1 ? '🔥 Close! Try a different approach' :
                                        attempts === 2 ? '💡 Check the hint for guidance' :
                                            '🎯 Review the vulnerable code carefully'}
                            </small>
                        </div>
                    )}
                </Card.Body>
            </Card>

            {/* Success Modal */}
            <Modal show={showSuccessModal} onHide={() => setShowSuccessModal(false)} centered>
                <Modal.Header className="bg-success text-white">
                    <Modal.Title>🎉 Exploit Successful!</Modal.Title>
                </Modal.Header>
                <Modal.Body className="text-center py-4">
                    <div className="display-1 mb-3">🏆</div>
                    <h4>Vulnerability Exploited!</h4>
                    <p className="mt-3">You've successfully compromised the vulnerable application.</p>
                    <code className="d-block p-2 bg-dark text-success rounded">
                        FLAG{`{${lab.id.toUpperCase()}_EXPLOIT_SUCCESS}`}
                    </code>
                    <Alert variant="success" className="mt-3">
                        <strong>Learning Point:</strong> Always validate and sanitize user input!
                    </Alert>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="success" onClick={() => setShowSuccessModal(false)}>
                        Continue Learning
                    </Button>
                </Modal.Footer>
            </Modal>

            {/* Vulnerability Modal */}
            <Modal show={showVulnerableModal} onHide={() => setShowVulnerableModal(false)} centered>
                <Modal.Header className="bg-danger text-white">
                    <Modal.Title>⚠️ Still Vulnerable!</Modal.Title>
                </Modal.Header>
                <Modal.Body className="text-center py-4">
                    <div className="display-1 mb-3">🔒</div>
                    <h4>Your payload didn't work</h4>
                    <p className="mt-3">The application is still secure against your attack.</p>
                    <Alert variant="danger">
                        <strong>💡 Tip:</strong> {lab.hint}
                    </Alert>
                    <Button
                        variant="info"
                        size="sm"
                        className="mt-2"
                        onClick={() => {
                            setUserInput(lab.examplePayload)
                            setShowVulnerableModal(false)
                        }}
                    >
                        Use Answer
                    </Button>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={() => setShowVulnerableModal(false)}>
                        Try Again
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default LabEnvironment