import { Navbar as BootstrapNavbar, Nav, Container, Button, Dropdown } from 'react-bootstrap'
import { useNavigate, Link } from 'react-router-dom'
import { FaUser, FaLock, FaChartLine, FaSignOutAlt, FaTachometerAlt } from 'react-icons/fa'
import { logout } from '../services/api'

function Navbar() {
    const navigate = useNavigate()
    const user = JSON.parse(localStorage.getItem('user') || '{}')

    const handleLogout = () => {
        logout() // This only removes token and user, NOT progress
        navigate('/login')
    }

    return (
        <BootstrapNavbar expand="lg" className="sticky-top" style={{ backgroundColor: '#111111', borderBottom: '1px solid #2a2a2a' }}>
            <Container>
                <BootstrapNavbar.Brand as={Link} to="/dashboard" className="fw-bold" style={{ color: '#00ff88' }}>
                    VulnSchool
                </BootstrapNavbar.Brand>
                <BootstrapNavbar.Toggle />
                <BootstrapNavbar.Collapse>
                    <Nav className="ms-auto align-items-center gap-2">
                        <Nav.Link as={Link} to="/dashboard" style={{ color: '#ffffff' }}><FaTachometerAlt className="me-1" /> Dashboard</Nav.Link>
                        <Nav.Link as={Link} to="/progress" style={{ color: '#ffffff' }}><FaChartLine className="me-1" /> Progress</Nav.Link>

                        <Dropdown align="end">
                            <Dropdown.Toggle as="div" style={{ cursor: 'pointer' }}>
                                <div className="rounded-circle d-flex align-items-center justify-content-center"
                                    style={{ width: '40px', height: '40px', background: '#00ff88', color: '#0a0a0a' }}>
                                    {user.name?.charAt(0)?.toUpperCase() || 'U'}
                                </div>
                            </Dropdown.Toggle>
                            <Dropdown.Menu style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                                <Dropdown.Item as={Link} to="/profile" style={{ color: '#ffffff' }}><FaUser className="me-2" /> Profile</Dropdown.Item>
                                <Dropdown.Item as={Link} to="/change-password" style={{ color: '#ffffff' }}><FaLock className="me-2" /> Change Password</Dropdown.Item>
                                <Dropdown.Item as={Link} to="/progress" style={{ color: '#ffffff' }}><FaChartLine className="me-2" /> Progress</Dropdown.Item>
                                <Dropdown.Divider style={{ borderColor: '#2a2a2a' }} />
                                <Dropdown.Item onClick={handleLogout} style={{ color: '#ff3366' }}><FaSignOutAlt className="me-2" /> Logout</Dropdown.Item>
                            </Dropdown.Menu>
                        </Dropdown>
                    </Nav>
                </BootstrapNavbar.Collapse>
            </Container>
        </BootstrapNavbar>
    )
}

export default Navbar