import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaUser, FaEnvelope, FaSave, FaBriefcase, FaGraduationCap } from 'react-icons/fa'

function Profile() {
    // eslint-disable-next-line no-unused-vars
    const navigate = useNavigate()
    const [user, setUser] = useState({})
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        role: 'Student',
        company: '',
        bio: ''
    })
    const [message, setMessage] = useState('')
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user') || '{}')
        const profileData = JSON.parse(localStorage.getItem('userProfile') || '{}')
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setUser(userData)
        setFormData({
            name: userData.name || '',
            email: userData.email || '',
            role: profileData.role || 'Student',
            company: profileData.company || '',
            bio: profileData.bio || ''
        })
    }, [])

    const handleSubmit = (e) => {
        e.preventDefault()
        setLoading(true)

        const profileData = {
            role: formData.role,
            company: formData.company,
            bio: formData.bio,
            updatedAt: new Date().toISOString()
        }

        localStorage.setItem('userProfile', JSON.stringify(profileData))

        if (formData.name !== user.name) {
            const updatedUser = { ...user, name: formData.name }
            localStorage.setItem('user', JSON.stringify(updatedUser))
            setUser(updatedUser)
        }

        setMessage('Profile updated successfully!')
        setTimeout(() => setMessage(''), 3000)
        setLoading(false)
    }

    // Get progress for this user
    const userEmail = user.email
    const allProgress = JSON.parse(localStorage.getItem('allModuleProgress') || '{}')
    const userProgress = allProgress[userEmail] || {}
    const completedCount = Object.values(userProgress).filter(p => p.status === 'completed').length

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }}>
            <Container className="py-4">
                <Row>
                    <Col lg={4} className="mb-4">
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }} className="text-center">
                            <Card.Body className="p-4">
                                <div className="rounded-circle d-flex align-items-center justify-content-center mx-auto"
                                    style={{ width: '120px', height: '120px', background: '#00ff88', color: '#0a0a0a', fontSize: '3rem', fontWeight: 'bold' }}>
                                    {user.name?.charAt(0) || 'U'}
                                </div>
                                <h3 className="mt-3" style={{ color: '#ffffff' }}>{user.name || 'User'}</h3>
                                <p style={{ color: '#00ff88' }}>{formData.role}</p>
                                <p className="small" style={{ color: '#9ca3af' }}>
                                    <FaEnvelope className="me-1" /> {user.email}
                                </p>
                                <hr style={{ borderColor: '#2a2a2a' }} />
                                <div className="text-start">
                                    <h6 style={{ color: '#00ff88' }}>📊 Statistics</h6>
                                    <div className="d-flex justify-content-between mb-2" style={{ color: '#ffffff' }}>
                                        <span>Modules Completed:</span>
                                        <strong style={{ color: '#00ff88' }}>{completedCount}/10</strong>
                                    </div>
                                    <div className="d-flex justify-content-between" style={{ color: '#ffffff' }}>
                                        <span>Member Since:</span>
                                        <strong style={{ color: '#00ff88' }}>{new Date().toLocaleDateString()}</strong>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col lg={8}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-4">
                                <h3 style={{ color: '#00ff88' }}>Edit Profile</h3>
                                <p style={{ color: '#9ca3af' }} className="mb-4">Update your personal information</p>

                                {message && <Alert variant="success">{message}</Alert>}

                                <Form onSubmit={handleSubmit}>
                                    <Row>
                                        <Col md={6} className="mb-3">
                                            <Form.Label style={{ color: '#ffffff' }}>Full Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                value={formData.name}
                                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                                style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                            />
                                        </Col>
                                        <Col md={6} className="mb-3">
                                            <Form.Label style={{ color: '#ffffff' }}>Email</Form.Label>
                                            <Form.Control
                                                type="email"
                                                value={formData.email}
                                                disabled
                                                style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#9ca3af' }}
                                            />
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col md={6} className="mb-3">
                                            <Form.Label style={{ color: '#ffffff' }}>Role</Form.Label>
                                            <Form.Select
                                                value={formData.role}
                                                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                                                style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                            >
                                                <option value="Student">🎓 Student</option>
                                                <option value="Professional">💼 Professional</option>
                                                <option value="Penetration Tester">🔐 Penetration Tester</option>
                                                <option value="Security Analyst">🛡️ Security Analyst</option>
                                                <option value="Developer">👨‍💻 Developer</option>
                                                <option value="Security Architect">🏛️ Security Architect</option>
                                            </Form.Select>
                                        </Col>
                                        <Col md={6} className="mb-3">
                                            <Form.Label style={{ color: '#ffffff' }}>Company/Organization</Form.Label>
                                            <Form.Control
                                                type="text"
                                                value={formData.company}
                                                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                                                placeholder="Your company"
                                                style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                            />
                                        </Col>
                                    </Row>

                                    <div className="mb-4">
                                        <Form.Label style={{ color: '#ffffff' }}>Bio</Form.Label>
                                        <Form.Control
                                            as="textarea"
                                            rows={4}
                                            value={formData.bio}
                                            onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                                            placeholder="Tell us about yourself..."
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </div>

                                    <Button
                                        type="submit"
                                        style={{
                                            background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                            border: 'none',
                                            color: '#0a0a0a',
                                            fontWeight: 'bold',
                                            padding: '10px 30px'
                                        }}
                                        disabled={loading}
                                    >
                                        <FaSave className="me-2" /> {loading ? 'Saving...' : 'Save Changes'}
                                    </Button>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Profile