import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'
import { register } from '../services/api'

function Register() {
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [error, setError] = useState('')
    const [success, setSuccess] = useState('')
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate()

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        setError('')
        setSuccess('')

        if (password !== confirmPassword) {
            setError('Passwords do not match')
            setLoading(false)
            return
        }

        if (password.length < 6) {
            setError('Password must be at least 6 characters')
            setLoading(false)
            return
        }

        try {
            const result = await register(name, email, password)

            if (result && result.success) {
                setSuccess('Registration successful! Redirecting to login...')
                setTimeout(() => navigate('/login'), 2000)
            } else {
                setError(result?.message || 'Registration failed')
            }
        // eslint-disable-next-line no-unused-vars
        } catch (err) {
            setError('Network error. Make sure backend is running on port 8080')
        }

        setLoading(false)
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh', display: 'flex', alignItems: 'center' }}>
            <Container>
                <Row className="justify-content-center">
                    <Col md={6} lg={5}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-5">
                                <div className="text-center mb-4">
                                    <div style={{ fontSize: '48px' }}>🛡️</div>
                                    <h1 style={{ color: '#00ff88' }}>VulnSchool</h1>
                                    <p style={{ color: '#9ca3af' }}>Start Your Security Journey</p>
                                </div>

                                {error && <Alert variant="danger">{error}</Alert>}
                                {success && <Alert variant="success">{success}</Alert>}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Full Name</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Enter your name"
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Email Address</Form.Label>
                                        <Form.Control
                                            type="email"
                                            placeholder="Enter your email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            placeholder="Min 6 characters"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <Form.Label style={{ color: '#ffffff' }}>Confirm Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            placeholder="Confirm your password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Button
                                        type="submit"
                                        style={{
                                            background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                            border: 'none',
                                            color: '#0a0a0a',
                                            fontWeight: 'bold',
                                            width: '100%',
                                            padding: '10px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? 'Registering...' : 'Create Account'}
                                    </Button>
                                </Form>

                                <hr style={{ borderColor: '#2a2a2a', margin: '20px 0' }} />

                                <div className="text-center">
                                    <span style={{ color: '#9ca3af' }}>Already have an account? </span>
                                    <Link to="/login" style={{ color: '#00ff88' }}>Login here</Link>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Register