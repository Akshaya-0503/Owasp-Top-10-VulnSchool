import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, ProgressBar, Badge, Button, Spinner } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaChartLine, FaCheckCircle, FaClock, FaBook, FaUserGraduate } from 'react-icons/fa'
import { getCurrentUser, getUserProgress } from '../services/api'

function Progress() {
    const navigate = useNavigate()
    const [modules, setModules] = useState([])
    const [user, setUser] = useState(null)
    const [loading, setLoading] = useState(true)
    const [refreshing, setRefreshing] = useState(false)

    const allModules = [
        { id: 'A01', title: 'Broken Access Control', difficulty: 'Medium', labs: 2 },
        { id: 'A02', title: 'Security Misconfiguration', difficulty: 'Easy', labs: 1 },
        { id: 'A03', title: 'Injection', difficulty: 'Medium', labs: 1 },
        { id: 'A04', title: 'Cryptographic Failures', difficulty: 'Medium', labs: 1 },
        { id: 'A05', title: 'Cross-Site Scripting (XSS)', difficulty: 'Medium', labs: 1 },
        { id: 'A06', title: 'Insecure Design', difficulty: 'Hard', labs: 1 },
        { id: 'A07', title: 'Authentication Failures', difficulty: 'Easy', labs: 1 },
        { id: 'A08', title: 'Software Integrity Failures', difficulty: 'Hard', labs: 1 },
        { id: 'A09', title: 'Security Logging Failures', difficulty: 'Medium', labs: 1 },
        { id: 'A10', title: 'Exception Handling', difficulty: 'Medium', labs: 1 }
    ]

    const loadProgress = async (showRefresh = false) => {
        if (showRefresh) setRefreshing(true)
        else setLoading(true)

        try {
            const currentUser = getCurrentUser()
            if (!currentUser) {
                setUser(null)
                return
            }
            setUser(currentUser)

            // Get progress from backend
            const result = await getUserProgress()
            console.log('Progress data:', result)

            let userProgress = {}
            if (result.success && result.progress) {
                userProgress = result.progress
            } else {
                // Fallback to localStorage
                const savedProgress = localStorage.getItem(`moduleProgress_${currentUser.id}`)
                if (savedProgress) {
                    userProgress = JSON.parse(savedProgress)
                }
            }

            const updatedModules = allModules.map(module => {
                const progress = userProgress[module.id]
                return {
                    ...module,
                    status: progress?.status || 'not-started',
                    completedLabs: progress?.completedLabs?.length || 0,
                }
            })
            setModules(updatedModules)
        } catch (error) {
            console.error('Error loading progress:', error)
        } finally {
            setLoading(false)
            setRefreshing(false)
        }
    }

    useEffect(() => {
        loadProgress()
    }, [])

    const getStatusBadge = (status) => {
        switch (status) {
            case 'completed':
                return <Badge bg="success" style={{ padding: '8px 12px' }}>✅ Completed</Badge>
            case 'in-progress':
                return <Badge bg="warning" text="dark" style={{ padding: '8px 12px' }}>⚡ In Progress</Badge>
            default:
                return <Badge bg="secondary" style={{ padding: '8px 12px' }}>📚 Not Started</Badge>
        }
    }

    const completedCount = modules.filter(m => m.status === 'completed').length
    const inProgressCount = modules.filter(m => m.status === 'in-progress').length
    const totalLabsCompleted = modules.reduce((sum, m) => sum + m.completedLabs, 0)
    const overallProgress = (completedCount / modules.length) * 100

    if (loading) {
        return (
            <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <Spinner animation="border" variant="success" style={{ width: '3rem', height: '3rem' }} />
                <p className="ms-3" style={{ color: '#ffffff' }}>Loading your progress...</p>
            </div>
        )
    }

    if (!user) {
        return (
            <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }}>
                <Container className="py-5">
                    <div className="text-center">
                        <h2 style={{ color: '#ffffff' }}>Not Logged In</h2>
                        <p style={{ color: '#9ca3af' }}>Please login to view your progress</p>
                        <Button variant="success" onClick={() => navigate('/login')}>
                            Go to Login
                        </Button>
                    </div>
                </Container>
            </div>
        )
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }}>
            <Container className="py-4">
                {/* Refresh Button */}
                <div className="text-end mb-3">
                    <Button
                        variant="outline-success"
                        size="sm"
                        onClick={() => loadProgress(true)}
                        disabled={refreshing}
                        style={{ borderColor: '#00ff88', color: '#00ff88' }}
                    >
                        {refreshing ? 'Refreshing...' : '⟳ Refresh Progress'}
                    </Button>
                </div>

                {/* Header Card */}
                <Card style={{ background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }} className="mb-4 border-0">
                    <Card.Body>
                        <div className="d-flex justify-content-between align-items-center flex-wrap">
                            <div>
                                <h2 className="mb-2" style={{ color: '#00ff88' }}>
                                    <FaUserGraduate className="me-2" /> {user.name || 'Student'}'s Learning Progress
                                </h2>
                                <p style={{ color: '#9ca3af' }}>Track your journey through OWASP Top 10 2025</p>
                            </div>
                            <Badge bg="primary" className="p-2" style={{ background: 'linear-gradient(135deg, #00ff88, #00b4d8)', color: '#0a0a0a' }}>
                                {user.email}
                            </Badge>
                        </div>
                        <div className="mt-3">
                            <div className="d-flex justify-content-between mb-2">
                                <span style={{ color: '#ffffff' }}>Overall Progress</span>
                                <span className="fw-bold" style={{ color: '#00ff88' }}>{Math.round(overallProgress)}%</span>
                            </div>
                            <ProgressBar
                                now={overallProgress}
                                variant="success"
                                className="rounded-pill"
                                style={{ height: '10px' }}
                            />
                            <small className="mt-2 d-block" style={{ color: '#9ca3af' }}>
                                {completedCount} of {modules.length} modules completed
                            </small>
                        </div>
                    </Card.Body>
                </Card>

                {/* Stats Cards */}
                <Row className="mb-4 g-3">
                    <Col md={3} sm={6}>
                        <Card className="text-center p-3 border-0" style={{ backgroundColor: '#1a1a1a' }}>
                            <FaCheckCircle size={40} style={{ color: '#00ff88' }} />
                            <h2 className="mt-2 mb-0" style={{ color: '#ffffff', fontSize: '2rem' }}>{completedCount}</h2>
                            <p className="mb-0" style={{ color: '#9ca3af' }}>Completed</p>
                        </Card>
                    </Col>
                    <Col md={3} sm={6}>
                        <Card className="text-center p-3 border-0" style={{ backgroundColor: '#1a1a1a' }}>
                            <FaClock size={40} style={{ color: '#ffd700' }} />
                            <h2 className="mt-2 mb-0" style={{ color: '#ffffff', fontSize: '2rem' }}>{inProgressCount}</h2>
                            <p className="mb-0" style={{ color: '#9ca3af' }}>In Progress</p>
                        </Card>
                    </Col>
                    <Col md={3} sm={6}>
                        <Card className="text-center p-3 border-0" style={{ backgroundColor: '#1a1a1a' }}>
                            <FaBook size={40} style={{ color: '#00b4d8' }} />
                            <h2 className="mt-2 mb-0" style={{ color: '#ffffff', fontSize: '2rem' }}>{totalLabsCompleted}</h2>
                            <p className="mb-0" style={{ color: '#9ca3af' }}>Labs Done</p>
                        </Card>
                    </Col>
                    <Col md={3} sm={6}>
                        <Card className="text-center p-3 border-0" style={{ backgroundColor: '#1a1a1a' }}>
                            <FaChartLine size={40} style={{ color: '#7b2cbf' }} />
                            <h2 className="mt-2 mb-0" style={{ color: '#ffffff', fontSize: '2rem' }}>{Math.round(overallProgress)}%</h2>
                            <p className="mb-0" style={{ color: '#9ca3af' }}>Mastery</p>
                        </Card>
                    </Col>
                </Row>

                {/* Progress Table */}
                <Card style={{ backgroundColor: '#1a1a1a' }} className="border-0">
                    <Card.Body className="p-0">
                        <div style={{ overflowX: 'auto' }}>
                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                <thead style={{ backgroundColor: '#2a2a2a' }}>
                                    <tr>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Module</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Title</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Difficulty</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Labs</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Status</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Progress</th>
                                        <th style={{ padding: '12px', textAlign: 'left', color: '#00ff88' }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {modules.map((module) => (
                                        <tr key={module.id} style={{ borderBottom: '1px solid #2a2a2a' }}>
                                            <td style={{ padding: '12px', fontWeight: 'bold', color: '#ffffff' }}>{module.id}</td>
                                            <td style={{ padding: '12px', color: '#ffffff' }}>{module.title}</td>
                                            <td style={{ padding: '12px' }}>
                                                <Badge bg={
                                                    module.difficulty === 'Easy' ? 'success' :
                                                        module.difficulty === 'Medium' ? 'warning' : 'danger'
                                                }>
                                                    {module.difficulty}
                                                </Badge>
                                            </td>
                                            <td style={{ padding: '12px', color: '#ffffff' }}>{module.completedLabs}/{module.labs}</td>
                                            <td style={{ padding: '12px' }}>{getStatusBadge(module.status)}</td>
                                            <td style={{ padding: '12px', width: '150px' }}>
                                                <ProgressBar
                                                    now={(module.completedLabs / module.labs) * 100}
                                                    variant={module.status === 'completed' ? 'success' : 'primary'}
                                                    className="rounded-pill"
                                                    style={{ height: '8px' }}
                                                />
                                                <div style={{ textAlign: 'center', marginTop: '4px' }}>
                                                    <small style={{ color: '#9ca3af', fontSize: '10px' }}>
                                                        {Math.round((module.completedLabs / module.labs) * 100)}%
                                                    </small>
                                                </div>
                                            </td>
                                            <td style={{ padding: '12px' }}>
                                                <Button
                                                    variant="outline-primary"
                                                    size="sm"
                                                    onClick={() => navigate(`/module/${module.id}`)}
                                                    style={{ borderColor: '#00ff88', color: '#00ff88', background: 'transparent' }}
                                                >
                                                    {module.status === 'completed' ? 'Review' :
                                                        module.status === 'in-progress' ? 'Continue' : 'Start'}
                                                </Button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card.Body>
                </Card>

                {/* No Progress Message */}
                {completedCount === 0 && inProgressCount === 0 && (
                    <div className="text-center mt-4 p-4" style={{ backgroundColor: '#1a1a1a', borderRadius: '12px' }}>
                        <h4 style={{ color: '#ffffff' }}>Welcome to your learning journey! 🚀</h4>
                        <p style={{ color: '#9ca3af' }}>You haven't started any modules yet. Click "Start" on any module to begin learning.</p>
                    </div>
                )}
            </Container>
        </div>
    )
}

export default Progress