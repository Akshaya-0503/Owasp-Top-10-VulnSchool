import { useState } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaLock, FaSave } from 'react-icons/fa'

function ChangePassword() {
    const navigate = useNavigate()
    const [currentPassword, setCurrentPassword] = useState('')
    const [newPassword, setNewPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [message, setMessage] = useState('')
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault()
        setError('')
        setMessage('')
        setLoading(true)

        if (newPassword.length < 6) {
            setError('New password must be at least 6 characters')
            setLoading(false)
            return
        }

        if (newPassword !== confirmPassword) {
            setError('New passwords do not match')
            setLoading(false)
            return
        }

        try {
            const token = localStorage.getItem('token')
            const user = JSON.parse(localStorage.getItem('user') || '{}')

            console.log('Token:', token)
            console.log('User:', user)

            if (!token) {
                setError('Not logged in. Please login again.')
                setLoading(false)
                return
            }

            const response = await fetch('http://localhost:8080/api/auth/change-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    currentPassword: currentPassword,
                    newPassword: newPassword
                })
            })

            const data = await response.json()
            console.log('Password change response:', data)

            if (data.success === 'true' || data.success === true) {
                setMessage('Password changed successfully! Redirecting...')
                setTimeout(() => navigate('/profile'), 2000)
            } else {
                setError(data.message || 'Failed to change password')
            }
        } catch (err) {
            console.error('Password change error:', err)
            setError('Network error. Please try again.')
        }

        setLoading(false)
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }}>
            <Container className="py-5">
                <Row className="justify-content-center">
                    <Col md={6}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-4">
                                <h3 className="mb-2" style={{ color: '#00ff88' }}>🔐 Change Password</h3>
                                <p className="mb-4" style={{ color: '#9ca3af' }}>Update your account password</p>

                                {message && <Alert variant="success">{message}</Alert>}
                                {error && <Alert variant="danger">{error}</Alert>}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Current Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            value={currentPassword}
                                            onChange={(e) => setCurrentPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>New Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            value={newPassword}
                                            onChange={(e) => setNewPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                        <Form.Text style={{ color: '#9ca3af' }}>Min 6 characters</Form.Text>
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <Form.Label style={{ color: '#ffffff' }}>Confirm New Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <div className="d-flex gap-2">
                                        <Button
                                            type="submit"
                                            style={{
                                                background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                                border: 'none',
                                                color: '#0a0a0a',
                                                fontWeight: 'bold',
                                                padding: '10px 30px'
                                            }}
                                            disabled={loading}
                                        >
                                            <FaSave className="me-2" /> {loading ? 'Changing...' : 'Change Password'}
                                        </Button>
                                        <Button
                                            variant="secondary"
                                            onClick={() => navigate('/profile')}
                                            style={{ backgroundColor: '#2a2a2a', border: 'none', color: '#ffffff' }}
                                        >
                                            Cancel
                                        </Button>
                                    </div>
                                </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default ChangePassword