import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Badge, Button, ProgressBar, Spinner } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaTrophy, FaFire, FaShieldAlt, FaTerminal, FaStar } from 'react-icons/fa'
import { getCurrentUser, getUserProgress, updateModuleProgress } from '../services/api'

function Dashboard() {
    const navigate = useNavigate()
    const [user, setUser] = useState({})
    const [progress, setProgress] = useState({})
    const [loading, setLoading] = useState(true)

    const modules = [
        { id: 'A01', title: 'Broken Access Control', difficulty: 'Medium', cvss: '7.5', description: 'Learn about IDOR and privilege escalation' },
        { id: 'A02', title: 'Security Misconfiguration', difficulty: 'Easy', cvss: '6.5', description: 'Learn about security headers and defaults' },
        { id: 'A03', title: 'Software Supply Chain Failures', difficulty: 'Hard', cvss: '8.2', description: 'Learn about supply chain security' },
        { id: 'A04', title: 'Cryptographic Failures', difficulty: 'Medium', cvss: '7.4', description: 'Learn about weak encryption and hashing' },
        { id: 'A05', title: 'Injection', difficulty: 'Medium', cvss: '9.0', description: 'Learn about SQL and NoSQL injection' },
        { id: 'A06', title: 'Insecure Design', difficulty: 'Hard', cvss: '7.1', description: 'Learn about security design flaws' },
        { id: 'A07', title: 'Authentication Failures', difficulty: 'Easy', cvss: '8.1', description: 'Learn about weak authentication' },
        { id: 'A08', title: 'Software Integrity Failures', difficulty: 'Hard', cvss: '7.8', description: 'Learn about supply chain attacks' },
        { id: 'A09', title: 'Security Logging Failures', difficulty: 'Medium', cvss: '6.8', description: 'Learn about monitoring and logging' },
        { id: 'A10', title: 'Exception Handling', difficulty: 'Medium', cvss: '6.2', description: 'Learn about proper error handling' }
    ]

    const loadProgress = async () => {
        setLoading(true)
        try {
            const userData = getCurrentUser()
            if (userData) {
                setUser(userData)
                const result = await getUserProgress()
                if (result.success && result.progress) {
                    setProgress(result.progress)
                } else {
                    const savedProgress = JSON.parse(localStorage.getItem(`moduleProgress_${userData.id}`) || '{}')
                    setProgress(savedProgress)
                }
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        loadProgress()
    }, [])

    const getModuleStatus = (moduleId) => {
        return progress[moduleId]?.status || 'not-started'
    }

    const handleStartLearning = async (moduleId) => {
        if (getModuleStatus(moduleId) === 'not-started') {
            const updatedProgress = {
                ...progress,
                [moduleId]: { status: 'in-progress', startedAt: new Date().toISOString(), completedLabs: [] }
            }
            await updateModuleProgress(moduleId, 'in-progress', [])
            setProgress(updatedProgress)
        }
        navigate(`/module/${moduleId}`)
    }

    const completedCount = modules.filter(m => getModuleStatus(m.id) === 'completed').length
    const inProgressCount = modules.filter(m => getModuleStatus(m.id) === 'in-progress').length
    const progressPercent = (completedCount / modules.length) * 100

    if (loading) {
        return (
            <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <Spinner animation="border" variant="success" style={{ width: '3rem', height: '3rem' }} />
                <p className="ms-3" style={{ color: '#ffffff' }}>Loading dashboard...</p>
            </div>
        )
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }}>
            <Container className="py-4">
                {/* Stats Cards */}
                <Row className="g-3 mb-4">
                    <Col md={3}>
                        <div style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: '12px', padding: '20px', textAlign: 'center' }}>
                            <FaTrophy size={35} style={{ color: '#00ff88' }} />
                            <h2 style={{ color: '#ffffff', fontSize: '32px', marginTop: '10px' }}>{completedCount}/{modules.length}</h2>
                            <p style={{ color: '#9ca3af', fontSize: '12px' }}>Modules Completed</p>
                        </div>
                    </Col>
                    <Col md={3}>
                        <div style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: '12px', padding: '20px', textAlign: 'center' }}>
                            <FaFire size={35} style={{ color: '#ffd700' }} />
                            <h2 style={{ color: '#ffffff', fontSize: '32px', marginTop: '10px' }}>{inProgressCount}</h2>
                            <p style={{ color: '#9ca3af', fontSize: '12px' }}>In Progress</p>
                        </div>
                    </Col>
                    <Col md={3}>
                        <div style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: '12px', padding: '20px', textAlign: 'center' }}>
                            <FaShieldAlt size={35} style={{ color: '#7b2cbf' }} />
                            <h2 style={{ color: '#ffffff', fontSize: '32px', marginTop: '10px' }}>{Math.round(progressPercent)}%</h2>
                            <p style={{ color: '#9ca3af', fontSize: '12px' }}>Mastery Level</p>
                        </div>
                    </Col>
                    <Col md={3}>
                        <div style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: '12px', padding: '20px', textAlign: 'center' }}>
                            <FaStar size={35} style={{ color: '#00b4d8' }} />
                            <h2 style={{ color: '#ffffff', fontSize: '32px', marginTop: '10px' }}>{modules.length - completedCount - inProgressCount}</h2>
                            <p style={{ color: '#9ca3af', fontSize: '12px' }}>Remaining</p>
                        </div>
                    </Col>
                </Row>

                {/* Welcome Section */}
                <div style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: '12px', padding: '24px', marginBottom: '24px' }}>
                    <div className="d-flex justify-content-between align-items-center flex-wrap">
                        <div>
                            <h1 style={{ color: '#00ff88', fontSize: '28px', marginBottom: '8px' }}>
                                Welcome back, {user.name || 'Warrior'}! 🥷
                            </h1>
                            <p style={{ color: '#9ca3af', marginBottom: '0' }}>Continue your security learning journey</p>
                        </div>
                        <div className="mt-3 mt-sm-0">
                            <div style={{ backgroundColor: '#2a2a2a', borderRadius: '10px', width: '200px', overflow: 'hidden' }}>
                                <div style={{ background: 'linear-gradient(90deg, #00ff88, #00b4d8)', width: `${progressPercent}%`, height: '8px' }}></div>
                            </div>
                            <small style={{ color: '#9ca3af' }}>{completedCount}/10 Completed</small>
                        </div>
                    </div>
                </div>

                {/* Modules Grid Header */}
                <h2 style={{ color: '#00ff88', fontSize: '20px', marginBottom: '8px' }}>
                    <FaTerminal style={{ marginRight: '8px' }} /> OWASP Top 10 Modules
                </h2>
                <p style={{ color: '#9ca3af', marginBottom: '24px' }}>Select a module to begin learning</p>

                {/* Modules Grid */}
                <Row className="g-4">
                    {modules.map((module) => {
                        const status = getModuleStatus(module.id)
                        return (
                            <Col md={6} lg={4} key={module.id}>
                                <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a', height: '100%' }}>
                                    <Card.Body>
                                        <div className="d-flex justify-content-between align-items-start mb-3">
                                            <Badge bg="primary" style={{ background: 'linear-gradient(135deg, #00ff88, #00b4d8)', color: '#0a0a0a' }}>
                                                {module.id}
                                            </Badge>
                                            <Badge bg={status === 'completed' ? 'success' : status === 'in-progress' ? 'warning' : 'secondary'}>
                                                {status === 'completed' ? '✓ Completed' : status === 'in-progress' ? '⚡ In Progress' : '🔒 Locked'}
                                            </Badge>
                                        </div>
                                        <Card.Title style={{ color: '#ffffff' }}>{module.title}</Card.Title>
                                        <Card.Text style={{ color: '#9ca3af', fontSize: '13px' }}>
                                            Difficulty: {module.difficulty} | CVSS: {module.cvss}
                                        </Card.Text>
                                        <Card.Text style={{ color: '#6b7280', fontSize: '12px' }}>
                                            {module.description}
                                        </Card.Text>
                                        <Button
                                            onClick={() => handleStartLearning(module.id)}
                                            style={{
                                                background: status === 'completed' ? '#2a2a2a' : 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                                border: 'none',
                                                color: status === 'completed' ? '#00ff88' : '#0a0a0a',
                                                fontWeight: 'bold',
                                                width: '100%'
                                            }}
                                        >
                                            {status === 'completed' ? '📖 Review Module' :
                                                status === 'in-progress' ? '⏩ Continue Learning' :
                                                    '🚀 Start Learning'}
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        )
                    })}
                </Row>
            </Container>
        </div>
    )
}

export default Dashboard