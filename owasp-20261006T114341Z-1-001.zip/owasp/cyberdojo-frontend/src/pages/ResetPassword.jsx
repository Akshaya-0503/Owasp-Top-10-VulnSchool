import { useState, useEffect } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'

function ResetPassword() {
    const navigate = useNavigate()
    const location = useLocation()
    const [token, setToken] = useState('')
    const [newPassword, setNewPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [message, setMessage] = useState('')
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        const params = new URLSearchParams(location.search)
        const tokenParam = params.get('token')
        if (tokenParam) {
            // eslint-disable-next-line react-hooks/set-state-in-effect
            setToken(tokenParam)
        }
    }, [location])

    const handleSubmit = (e) => {
        e.preventDefault()
        setError('')
        setMessage('')
        setLoading(true)

        if (newPassword.length < 6) {
            setError('Password must be at least 6 characters')
            setLoading(false)
            return
        }

        if (newPassword !== confirmPassword) {
            setError('Passwords do not match')
            setLoading(false)
            return
        }

        if (!token) {
            setError('No reset token provided')
            setLoading(false)
            return
        }

        // Find user by reset token (in demo, we just show success)
        // In real app, you'd verify token from backend
        setMessage('Password reset successful! Redirecting to login...')
        setTimeout(() => navigate('/login'), 2000)
        setLoading(false)
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh' }} className="d-flex align-items-center">
            <Container>
                <Row className="justify-content-center">
                    <Col md={6} lg={5}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-5">
                                <div className="text-center mb-4">
                                    <div style={{ fontSize: '48px' }}>🔑</div>
                                    <h1 style={{ color: '#00ff88' }}>Reset Password</h1>
                                    <p style={{ color: '#9ca3af' }}>Create a new password for your account</p>
                                </div>

                                {message && <Alert variant="success">{message}</Alert>}
                                {error && <Alert variant="danger">{error}</Alert>}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Reset Token</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Enter your reset token"
                                            value={token}
                                            onChange={(e) => setToken(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                        <Form.Text className="text-muted-custom">
                                            Enter the token you received
                                        </Form.Text>
                                    </Form.Group>

                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>New Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            placeholder="Min 6 characters"
                                            value={newPassword}
                                            onChange={(e) => setNewPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <Form.Label style={{ color: '#ffffff' }}>Confirm Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            placeholder="Confirm your password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Button
                                        type="submit"
                                        style={{
                                            background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                            border: 'none',
                                            color: '#0a0a0a',
                                            fontWeight: 'bold',
                                            width: '100%',
                                            padding: '10px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? 'Resetting...' : 'Reset Password'}
                                    </Button>
                                </Form>

                                <hr style={{ borderColor: '#2a2a2a', margin: '20px 0' }} />

                                <div className="text-center">
                                    <Link to="/login" style={{ color: '#00ff88' }}>← Back to Login</Link>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default ResetPassword