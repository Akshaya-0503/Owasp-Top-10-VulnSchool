import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'
import { login } from '../services/api'

function Login() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate()

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        setError('')

        try {
            const result = await login(email, password)
            console.log('Login result:', result)

            if (result && result.success) {
                navigate('/dashboard')
            } else {
                setError(result?.message || 'Login failed. Please check your credentials.')
            }
        // eslint-disable-next-line no-unused-vars
        } catch (err) {
            setError('Network error. Make sure backend is running on port 8080')
        }

        setLoading(false)
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh', display: 'flex', alignItems: 'center' }}>
            <Container>
                <Row className="justify-content-center">
                    <Col md={6} lg={5}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-5">
                                <div className="text-center mb-4">
                                    <div style={{ fontSize: '48px' }}>🛡️</div>
                                    <h1 style={{ color: '#00ff88' }}>VulnSchool</h1>
                                    <p style={{ color: '#9ca3af' }}>Master OWASP Top 10 Security</p>
                                </div>

                                {error && <Alert variant="danger">{error}</Alert>}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Email Address</Form.Label>
                                        <Form.Control
                                            type="email"
                                            placeholder="Enter your email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-3">
                                        <Form.Label style={{ color: '#ffffff' }}>Password</Form.Label>
                                        <Form.Control
                                            type="password"
                                            placeholder="Enter your password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Button
                                        type="submit"
                                        style={{
                                            background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                            border: 'none',
                                            color: '#0a0a0a',
                                            fontWeight: 'bold',
                                            width: '100%',
                                            padding: '10px',
                                            marginTop: '10px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? 'Logging in...' : 'Login'}
                                    </Button>
                                </Form>

                                <hr style={{ borderColor: '#2a2a2a', margin: '20px 0' }} />

                                <div className="text-center">
                                    <span style={{ color: '#9ca3af' }}>New to CyberDojo? </span>
                                    <Link to="/register" style={{ color: '#00ff88' }}>Create Account</Link>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Login