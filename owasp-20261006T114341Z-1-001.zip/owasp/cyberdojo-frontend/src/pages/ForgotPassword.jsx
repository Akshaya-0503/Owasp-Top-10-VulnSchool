import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'

function ForgotPassword() {
    const [email, setEmail] = useState('')
    const [message, setMessage] = useState('')
    const [error, setError] = useState('')
    const [resetToken, setResetToken] = useState('')

    const handleSubmit = (e) => {
        e.preventDefault()

        // Check if email exists in users
        const users = JSON.parse(localStorage.getItem('users') || '[]')
        const userExists = users.find(u => u.email === email)

        if (userExists || email) {
            // Generate a random token
            const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 8)
            setResetToken(token)
            setMessage(`Password reset token generated! Use this token to reset your password.`)
            setError('')
        } else {
            setError('Email not found. Please register first.')
            setMessage('')
        }
    }

    return (
        <div style={{ backgroundColor: '#0a0a0a', minHeight: '100vh', display: 'flex', alignItems: 'center' }}>
            <Container>
                <Row className="justify-content-center">
                    <Col md={6} lg={5}>
                        <Card style={{ backgroundColor: '#1a1a1a', border: '1px solid #2a2a2a' }}>
                            <Card.Body className="p-5">
                                <div className="text-center mb-4">
                                    <div style={{ fontSize: '48px' }}>🔐</div>
                                    <h1 style={{ color: '#00ff88' }}>Forgot Password?</h1>
                                    <p style={{ color: '#9ca3af' }}>We'll help you reset it</p>
                                </div>

                                {message && <Alert variant="success">{message}</Alert>}
                                {error && <Alert variant="danger">{error}</Alert>}

                                {resetToken && (
                                    <Alert variant="info" style={{ backgroundColor: '#2a2a2a', borderColor: '#00ff88', color: '#00ff88' }}>
                                        <strong>Your Reset Token:</strong>
                                        <code style={{ display: 'block', marginTop: '10px', padding: '8px', background: '#0a0a0a', borderRadius: '5px', wordBreak: 'break-all' }}>
                                            {resetToken}
                                        </code>
                                        <hr />
                                        <Link to={`/reset-password?token=${resetToken}`} style={{ color: '#00ff88' }}>
                                            Click here to reset password →
                                        </Link>
                                    </Alert>
                                )}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-4">
                                        <Form.Label style={{ color: '#ffffff' }}>Email Address</Form.Label>
                                        <Form.Control
                                            type="email"
                                            placeholder="Enter your registered email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                            style={{ backgroundColor: '#2a2a2a', borderColor: '#3a3a3a', color: '#ffffff' }}
                                        />
                                    </Form.Group>

                                    <Button
                                        type="submit"
                                        style={{
                                            background: 'linear-gradient(135deg, #00ff88, #00b4d8)',
                                            border: 'none',
                                            color: '#0a0a0a',
                                            fontWeight: 'bold',
                                            width: '100%',
                                            padding: '10px'
                                        }}
                                    >
                                        Send Reset Instructions
                                    </Button>
                                </Form>

                                <hr style={{ borderColor: '#2a2a2a', margin: '20px 0' }} />

                                <div className="text-center">
                                    <Link to="/login" style={{ color: '#00ff88' }}>← Back to Login</Link>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default ForgotPassword